"""
Flinza — Email Sender
SMTP send with Gmail account + alias rotation, optional SOCKS5/HTTP proxy per account,
daily limit tracking, bounce detection.
"""

import smtplib
import imaplib
import socket
import logging
import re
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr, make_msgid, formatdate
from urllib.parse import urlparse

from datetime import datetime
import time
import threading

import config
import email_toolkit
import requests
import database as db
import email_verifier
import outreach_engine

logger = logging.getLogger(__name__)

import google_auth
import tracking_server
import signature_generator

# Known bounce/block SMTP codes
BOUNCE_CODES = {550, 551, 552, 553, 554, 450, 421}


def send_via_cloudflare_api(from_email: str, to_email: str, subject: str, body: str, html_body: str = None, display_name: str = None) -> dict:
    """
    Dispatches outbound email directly via Cloudflare's Native Email Sending REST API.
    Available with Cloudflare Workers Paid tier ($5/month).
    Endpoint: POST https://api.cloudflare.com/client/v4/accounts/{account_id}/email/sending/send
    """
    account_id = config.CF_ACCOUNT_ID or db.get_setting("cf_account_id", "")
    api_token  = config.CF_API_TOKEN or db.get_setting("cf_api_token", "")

    if not account_id or not api_token:
        return {
            "success": False,
            "error": "Cloudflare CF_ACCOUNT_ID or CF_API_TOKEN is not configured in settings/.env"
        }

    url = f"https://api.cloudflare.com/client/v4/accounts/{account_id}/email/sending/send"
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Content-Type": "application/json"
    }

    from_addr = f"{display_name} <{from_email}>" if display_name else from_email
    payload = {
        "from": from_addr,
        "to": [to_email] if isinstance(to_email, str) else to_email,
        "subject": subject,
        "text": body,
        "html": html_body or body.replace("\n", "<br />\n")
    }

    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=20)
        data = resp.json()
        if data.get("success"):
            msg_id = data.get("result", {}).get("id") or make_msgid(domain=from_email.split("@")[-1] if "@" in from_email else "cloudflare.com")
            return {
                "success": True,
                "message_id": msg_id,
                "account_used": from_email,
                "provider": "cloudflare_api"
            }
        else:
            errors = data.get("errors", [])
            err_msg = errors[0].get("message") if errors else resp.text
            return {
                "success": False,
                "error": f"Cloudflare Email API error: {err_msg}",
                "status_code": resp.status_code
            }
    except Exception as e:
        logger.error(f"Cloudflare email send exception: {e}")
        return {"success": False, "error": str(e)}


def send_via_smtp2go_api(api_key: str, from_email: str, to_email: str, subject: str, body: str, html_body: str = None, display_name: str = None) -> dict:
    """Dispatches outbound email via SMTP2GO REST API v3."""
    url = "https://api.smtp2go.com/v3/email/send"
    headers = {"Content-Type": "application/json"}
    from_addr = f"{display_name} <{from_email}>" if display_name else from_email
    payload = {
        "api_key": api_key,
        "to": [to_email] if isinstance(to_email, str) else to_email,
        "sender": from_addr,
        "subject": subject,
        "text_body": body,
        "html_body": html_body or body.replace("\n", "<br />\n")
    }
    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=20)
        data = resp.json()
        if data.get("data", {}).get("succeeded", 0) > 0:
            email_id = data.get("data", {}).get("email_id") or make_msgid(domain="smtp2go.com")
            return {"success": True, "provider": "smtp2go_api", "message_id": email_id, "account_used": from_email}
        err = data.get("data", {}).get("error") or resp.text
        return {"success": False, "error": f"SMTP2GO API error: {err}", "account_used": from_email}
    except Exception as e:
        return {"success": False, "error": str(e), "account_used": from_email}


def send_via_mailjet_api(api_key: str, secret_key: str, from_email: str, to_email: str, subject: str, body: str, html_body: str = None, display_name: str = None) -> dict:
    """Dispatches outbound email via Mailjet REST API v3.1."""
    url = "https://api.mailjet.com/v3.1/send"
    from_payload = {"Email": from_email}
    if display_name:
        from_payload["Name"] = display_name
    payload = {
        "Messages": [
            {
                "From": from_payload,
                "To": [{"Email": to_email}],
                "Subject": subject,
                "TextPart": body,
                "HTMLPart": html_body or body.replace("\n", "<br />\n")
            }
        ]
    }
    try:
        resp = requests.post(url, json=payload, auth=(api_key, secret_key), timeout=20)
        data = resp.json()
        messages = data.get("Messages", [])
        if messages and messages[0].get("Status") == "success":
            to_info = messages[0].get("To", [{}])
            msg_id = str(to_info[0].get("MessageID")) if to_info else make_msgid(domain="mailjet.com")
            return {"success": True, "provider": "mailjet_api", "message_id": msg_id, "account_used": from_email}
        err = resp.text
        return {"success": False, "error": f"Mailjet API error: {err}", "account_used": from_email}
    except Exception as e:
        return {"success": False, "error": str(e), "account_used": from_email}


def send_email_now(to_email: str, subject: str, body: str, account: dict, tracking_token: str = None, extra_headers: dict = None) -> dict:
    """
    Send an email immediately using the given account dict.
    Supports:
      1. Cloudflare Native Email Sending REST API ($5/mo Workers Paid)
      2. Google OAuth 2.0 Gmail REST API
      3. SMTP2GO & Mailjet REST APIs
      4. Brevo, Amazon SES, Gmail, Namecheap, Zoho, Outlook SMTP relays
    """
    from_email   = account.get("from_email") or account.get("email")
    if not from_email:
        raise ValueError("Account dictionary must have 'from_email' or 'email'")
    provider     = account.get("provider") or ("spacemail" if (account.get("smtp_host") == "mail.spacemail.com" or "@flinzamedia.com" in str(from_email)) else ("gmail" if account.get("type") == "gmail" else "spacemail"))
    smtp_user    = account.get("smtp_user") or from_email
    smtp_pass    = account.get("smtp_pass") or account.get("app_password")
    proxy_url    = account.get("proxy_url")
    # Ensure display_name uses the mailbox owner's first name (e.g. Hannah for hannah@..., Raifa for raifa@...)
    # Never allow generic "Flinza Fleet", "Spacemail", or system labels to appear as the sender's name
    sender_first = _make_display_name(from_email)
    raw_name = (account.get("display_name") or account.get("label") or "").strip()
    if not raw_name or any(g in raw_name.lower() for g in ("flinza fleet", "spacemail", "gmail", "fleet")):
        display_name = sender_first
    else:
        display_name = raw_name
    acct_type    = account.get("type", "spacemail")

    # 1. Resolve Spintax in subject and body for unique fingerprinting
    subject = email_toolkit.resolve_spintax(subject)
    body = email_toolkit.resolve_spintax(body)

    # Strip AI em dashes (—) and en dashes (–) for natural human authenticity
    if subject:
        subject = subject.replace("—", " - ").replace("–", " - ")
        subject = re.sub(r"\s*-\s*", " - ", subject).strip()
    if body:
        body = body.replace(" — ", ", ").replace("—", ", ")
        body = body.replace(" – ", " - ").replace("–", " - ")

    # 2. Append opt-out footer if enabled
    if db.get_setting("optout_footer_enabled", "0") == "1":
        optout_text = db.get_setting("optout_text", "")
        if optout_text and optout_text not in body:
            body = body + optout_text

    # 3. Build message body — plain text ONLY for cold outreach (no HTML = no spam triggers)
    sig_cfg  = signature_generator.get_signature_settings()
    use_html = db.get_setting("html_email_enabled", "0") == "1"

    plain_text_body = body

    # Append plain-text signature
    if sig_cfg.get("sig_enabled", "1") == "1":
        # Dynamic sender persona:
        # Each mailbox persona signs off with its OWN name (e.g. Raifa for raifa@flinzaworks.in, Zoya for zoya@...)
        sender_first = _make_display_name(from_email)
        if " from " in sender_first:
            sender_first = sender_first.split(" from ")[0].strip()

        cfg_name = (sig_cfg.get("sig_name") or "").strip()
        # If cfg_name is the generic default "Alex Vance", dynamically use the actual mailbox sender (e.g. Raifa)
        if cfg_name and cfg_name != "Alex Vance":
            sig_name = cfg_name
        else:
            sig_name = sender_first or cfg_name or "Raifa"

        sig_title   = sig_cfg.get("sig_title", "")
        sig_company = sig_cfg.get("sig_company", "")
        sig_phone   = sig_cfg.get("sig_phone", "")
        plain_signoff = f"\n\n--\n{sig_name}"
        if sig_title:
            plain_signoff += f"\n{sig_title}"
        if sig_company:
            plain_signoff += f" · {sig_company}"
        if sig_phone:
            plain_signoff += f"\n{sig_phone}"
        if plain_signoff.strip() not in plain_text_body:
            plain_text_body = plain_text_body + plain_signoff

    html_body = None
    if use_html:
        html_content = plain_text_body.replace("\n", "<br />\n")
        html_body = f'<div style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.6; color: #333;">{html_content}</div>'

    body = plain_text_body

    # 4. Mode 1: Cloudflare Native Email Sending REST API (only when enabled and configured)
    cf_account_id = config.CF_ACCOUNT_ID or db.get_setting("cf_account_id", "")
    cf_api_token  = config.CF_API_TOKEN or db.get_setting("cf_api_token", "")
    if provider == "cloudflare_api" and cf_account_id and cf_api_token:
        logger.info(f"Dispatching via Cloudflare Email Sending API for {from_email}")
        res = send_via_cloudflare_api(
            from_email=from_email,
            to_email=to_email,
            subject=subject,
            body=body,
            html_body=html_body,
            display_name=display_name
        )
        if res.get("success"):
            db.increment_account_sent(account["id"], is_alias=(acct_type == "alias"))
            return res
        else:
            logger.warning(f"Cloudflare API dispatch failed for {from_email}: {res.get('error')}. Falling back to SMTP.")

    # 5. Mode 2: SMTP2GO REST API
    if provider == "smtp2go_api" and smtp_pass:
        logger.info(f"Dispatching via SMTP2GO API for {from_email}")
        res = send_via_smtp2go_api(
            api_key=smtp_pass,
            from_email=from_email,
            to_email=to_email,
            subject=subject,
            body=body,
            html_body=html_body,
            display_name=display_name
        )
        if res.get("success"):
            db.increment_account_sent(account["id"], is_alias=(acct_type == "alias"))
            return res

    # 6. Mode 3: Mailjet REST API
    if provider == "mailjet_api" and smtp_user and smtp_pass:
        logger.info(f"Dispatching via Mailjet API for {from_email}")
        res = send_via_mailjet_api(
            api_key=smtp_user,
            secret_key=smtp_pass,
            from_email=from_email,
            to_email=to_email,
            subject=subject,
            body=body,
            html_body=html_body,
            display_name=display_name
        )
        if res.get("success"):
            db.increment_account_sent(account["id"], is_alias=(acct_type == "alias"))
            return res

    # 7. Mode 4: Google OAuth 2.0 Gmail API dispatch
    if (provider in ("gmail", "oauth") or acct_type == "gmail") and db.get_oauth_token(from_email):
        logger.info(f"Dispatching via Google OAuth2 Gmail API for {from_email}")
        res = google_auth.send_via_gmail_api(
            from_email=from_email,
            to_email=to_email,
            subject=subject,
            body=body,
            display_name=display_name,
        )
        if res.get("success"):
            db.increment_account_sent(account["id"], is_alias=False)
            return res
        else:
            logger.warning(f"Google OAuth dispatch failed for {from_email}: {res.get('error')}. Falling back to SMTP.")

    # 8. Mode 5: SMTP dispatch (Amazon SES, Brevo, SMTP2GO, Mailjet, Gmail, Custom)
    default_hosts = {
        "brevo": "smtp-relay.brevo.com",
        "smtp2go": "mail.smtp2go.com",
        "mailjet": "in-v3.mailjet.com",
        "amazon_ses": db.get_setting("aws_ses_smtp_host", "email-smtp.eu-north-1.amazonaws.com"),
        "gmail": "smtp.gmail.com",
        "namecheap": "mail.privateemail.com",
        "zoho": "smtp.zoho.com",
        "zoho_in": "smtppro.zoho.in",
        "outlook": "smtp.office365.com",
        "sendgrid": "smtp.sendgrid.net",
        "spacemail": "mail.spacemail.com",
    }

    # Dynamic Relay Resolution for Aliases & Custom SMTP (SES vs Brevo rotation & failover)
    if acct_type == "alias" or provider in ("amazon_ses", "brevo", "custom", "external_smtp"):
        relay_info = db.get_active_relay_for_alias(from_email)
        provider = relay_info.get("provider", provider)
        target_host = relay_info.get("smtp_host") or default_hosts.get(provider, "smtp-relay.brevo.com")
        target_port = int(relay_info.get("smtp_port") or 587)
        smtp_user = relay_info.get("smtp_user") or smtp_user
        smtp_pass = relay_info.get("smtp_pass") or smtp_pass
        logger.info(f"Resolved relay for {from_email}: {provider} via {target_host}:{target_port} ({relay_info.get('reason')})")
    else:
        is_spacemail = (
            provider == "spacemail" or
            "spacemail" in str(account.get("smtp_host", "")).lower() or
            any(from_email.lower().endswith(dom) for dom in (
                "@flinzamedia.com", "@growflinza.com", "@flinzabiz.com", "@flinzaleads.com", "@flinzascales.com", "@flinzaoutreach.com"
            ))
        )
        if is_spacemail:
            provider = "spacemail"
            target_host = account.get("smtp_host") or "mail.spacemail.com"
            # Render free tier blocks port 465 (SSL) — use 587 (STARTTLS) instead
            target_port = int(account.get("smtp_port") or 587)
        else:
            target_host = account.get("smtp_host") or default_hosts.get(provider, "mail.spacemail.com")
            target_port = int(account.get("smtp_port") or (587 if provider in ("namecheap", "zoho_in", "spacemail") else 587))

    try:
        # Proper MIME formatting: use pure text/plain if no HTML, multipart/alternative only if HTML is present
        if html_body:
            msg = MIMEMultipart("alternative")
            msg.attach(MIMEText(body, "plain", "utf-8"))
            msg.attach(MIMEText(html_body, "html", "utf-8"))
        else:
            msg = MIMEText(body, "plain", "utf-8")

        msg["From"]         = formataddr((display_name, from_email))
        msg["To"]           = to_email
        msg["Subject"]      = subject
        msg["Reply-To"]     = formataddr((display_name, from_email))
        msg["Date"]         = formatdate(localtime=True)

        # If sending via alias — add Sender header only if smtp_user is a valid email and not external relay/API
        if from_email.lower() != smtp_user.lower() and "@" in smtp_user and provider not in ("amazon_ses", "brevo", "smtp2go", "mailjet", "sendgrid"):
            msg["Sender"] = formataddr((display_name, smtp_user))

        domain = from_email.split("@")[1] if "@" in from_email else "gmail.com"
        message_id = make_msgid(domain=domain)
        msg["Message-ID"] = message_id

        if extra_headers:
            for hk, hv in extra_headers.items():
                if hk not in msg:
                    msg[hk] = hv

        # Build SMTP connection (with optional proxy, port 465 SSL vs port 587 STARTTLS)
        active_node = None
        if not proxy_url and provider not in ("spacemail", "amazon_ses", "brevo", "smtp2go", "mailjet", "cloudflare_api"):
            # Route outbound outreach through smart IP rotator fleet pool (multi-node balancing)
            try:
                import ip_rotator
                active_node = ip_rotator.select_next_node()
                if active_node:
                    proxy_url = ip_rotator.build_proxy_url(active_node)
                    if proxy_url:
                        logger.info(f"🔄 Routing outreach email via IP Node #{active_node.get('id')} '{active_node.get('name')}' ({proxy_url})")
            except Exception as e:
                logger.warning(f"Failed resolving active IP node from rotator: {e}")

        smtp_conn = _make_smtp_connection(proxy_url, target_host=target_host, target_port=target_port)

        with smtp_conn as server:
            if target_port == 465:
                # Direct SSL connection (Spacemail, Namecheap Private Email, or Amazon SES SSL)
                server.ehlo()
            else:
                # STARTTLS connection (e.g. port 587 or 2525)
                server.ehlo()
                server.starttls()
                server.ehlo()
            if smtp_user and smtp_pass:
                server.login(smtp_user, smtp_pass)
            # Determine proper envelope sender (MAIL FROM) for strict DMARC/SPF compliance
            envelope_sender = from_email if ("@" not in smtp_user or provider in ("amazon_ses", "brevo", "smtp2go", "mailjet", "sendgrid", "namecheap", "spacemail") or acct_type == "alias") else smtp_user
            server.sendmail(envelope_sender, [to_email], msg.as_string())

        if active_node and active_node.get("id"):
            try:
                import ip_rotator
                ip_rotator.record_send_and_maybe_rotate(active_node["id"])
            except Exception as e_rot:
                logger.warning(f"Error recording IP node send / auto-rotate: {e_rot}")

        db.increment_account_sent(account["id"], is_alias=(acct_type == "alias"))
        domain_name = from_email.split("@")[-1].strip().lower() if "@" in from_email else ""
        db.record_smtp_dispatch(provider, domain_name)
        return {"success": True, "account_used": from_email, "message_id": message_id, "provider": provider}

    except smtplib.SMTPAuthenticationError as e:
        err_str = str(e)
        if "525" in err_str or "Unauthorized IP" in err_str:
            return {"success": False, "error": f"Brevo IP Security: Your sending IP is not authorized in Brevo dashboard. Add this IP under Brevo → Settings → Authorized IPs.", "account_used": from_email}
        return {"success": False, "error": f"Auth failed for {smtp_user}. Check SMTP password / API key.", "account_used": from_email}

    except smtplib.SMTPResponseException as e:
        code = e.smtp_code
        err_str = str(e.smtp_error) if hasattr(e, "smtp_error") else str(e)
        # Automatic Quota Failover: If Amazon SES hit daily quota limit or 554 rejection
        if provider == "amazon_ses" and (code == 554 or any(k in err_str.lower() for k in ["quota", "limit exceeded", "rate exceeded", "daily message"])):
            logger.warning(f"⚠️ Amazon SES quota limit exceeded ({code}: {err_str}). Triggering immediate failover to Brevo for {from_email}...")
            db.trigger_ses_quota_exceeded(err_str)
            domain_name = from_email.split("@")[-1].strip().lower() if "@" in from_email else ""
            domain_slug = domain_name.replace(".", "_")
            b_user = db.get_setting(f"brevo_user_{domain_slug}", "")
            b_pass = db.get_setting(f"brevo_pass_{domain_slug}", "")
            if b_user and b_pass:
                fallback_account = dict(account)
                fallback_account["provider"] = "brevo"
                fallback_account["smtp_host"] = "smtp-relay.brevo.com"
                fallback_account["smtp_port"] = 587
                fallback_account["smtp_user"] = b_user
                fallback_account["smtp_pass"] = b_pass
                logger.info(f"Retrying send immediately via Brevo SMTP failover for {from_email}...")
        if "jfe" in err_str.lower() or "jellyfish" in err_str.lower() or "high probability of spam" in err_str.lower():
            logger.error(f"🚨 Spacemail/Jellyfish anti-spam block for {from_email}: {err_str}. Domain authentication (DMARC) or copy flagged.")
            return {
                "success": False,
                "error": f"Spacemail Jellyfish Spam Block ({err_str}). Fix: Add DMARC TXT record for {from_email.split('@')[-1]} and avoid test gibberish.",
                "account_used": from_email,
                "is_spam_block": True
            }
        return {"success": False, "error": f"SMTP {code} error: {err_str}", "account_used": from_email}

    except smtplib.SMTPRecipientsRefused as e:
        code = list(e.recipients.values())[0][0] if e.recipients else 550
        error = f"Recipient refused ({code}): {to_email}"
        if code in BOUNCE_CODES and db.get_setting("bounce_blacklist", "1") == "1":
            db.add_to_blacklist(email=to_email, reason=f"SMTP bounce code {code}")
            lead = db.get_lead_by_email(to_email)
            if lead:
                db.blacklist_lead(lead["id"], f"SMTP bounce {code}")
            logger.warning(f"Auto-blacklisted {to_email} due to bounce {code}")
        return {"success": False, "error": error, "account_used": from_email, "bounce": True}

    except smtplib.SMTPException as e:
        err_str = str(e)
        if provider == "amazon_ses" and any(k in err_str.lower() for k in ["quota", "limit exceeded", "rate exceeded"]):
            logger.warning(f"⚠️ Amazon SES limit error: {err_str}. Triggering failover to Brevo...")
            db.trigger_ses_quota_exceeded(err_str)
            domain_name = from_email.split("@")[-1].strip().lower() if "@" in from_email else ""
            domain_slug = domain_name.replace(".", "_")
            b_user = db.get_setting(f"brevo_user_{domain_slug}", "")
            b_pass = db.get_setting(f"brevo_pass_{domain_slug}", "")
            if b_user and b_pass:
                fallback_account = dict(account)
                fallback_account["provider"] = "brevo"
                fallback_account["smtp_host"] = "smtp-relay.brevo.com"
                fallback_account["smtp_port"] = 587
                fallback_account["smtp_user"] = b_user
                fallback_account["smtp_pass"] = b_pass
                return send_email_now(to_email, subject, body, fallback_account, tracking_token, extra_headers)
        return {"success": False, "error": f"SMTP error: {err_str}", "account_used": from_email}

    except Exception as e:
        return {"success": False, "error": f"Send error: {str(e)}", "account_used": from_email}


def send_test_email(to_email: str, from_account_email: str = None, target_account: str = None) -> dict:
    """
    Sends a test email to verify mailbox deliverability, headers, and credentials.
    """
    import time
    start_t = time.time()

    from_account = from_account_email or target_account

    # Find account or pick next available
    account = None
    if from_account:
        target = from_account.strip().lower()
        # Check gmail accounts
        accs = db.get_all_accounts()
        for a in accs:
            if a["email"].lower() == target:
                account = {
                    "id": a["email"],
                    "type": a.get("provider") or "spacemail",
                    "from_email": a["email"],
                    "email": a["email"],
                    "smtp_user": a.get("smtp_user") or a["email"],
                    "smtp_pass": a.get("smtp_pass") or a.get("app_password"),
                    "provider": a.get("provider") or "spacemail",
                    "smtp_host": a.get("smtp_host") or "mail.spacemail.com",
                    "smtp_port": int(a.get("smtp_port") or 587),
                    "proxy_url": a.get("proxy_url"),
                    "display_name": a.get("label") or _make_display_name(a["email"])
                }
                break

        # Check aliases
        if not account:
            aliases = db.get_all_aliases()
            for al in aliases:
                if al["alias"].lower() == target:
                    al_d = dict(al)
                    account = {
                        "id": al_d["alias"],
                        "type": "alias",
                        "from_email": al_d["alias"],
                        "email": al_d["alias"],
                        "smtp_user": al_d.get("custom_smtp_user") or al_d.get("smtp_user"),
                        "smtp_pass": al_d.get("custom_smtp_pass") or al_d.get("smtp_pass"),
                        "provider": al_d.get("routing_mode", "gmail_send_as"),
                        "routing_mode": al_d.get("routing_mode", "gmail_send_as"),
                        "smtp_host": al_d.get("smtp_host"),
                        "smtp_port": al_d.get("smtp_port"),
                        "proxy_url": None,
                        "display_name": al_d.get("display_name") or _make_display_name(al_d["alias"])
                    }
                    break

    if not account:
        account = db.get_next_available_account()

    if not account:
        return {"success": False, "error": "No active mailboxes available in database."}

    if "from_email" not in account and "email" in account:
        account["from_email"] = account["email"]
    if "email" not in account and "from_email" in account:
        account["email"] = account["from_email"]
    if not account.get("smtp_host"):
        account["smtp_host"] = "mail.spacemail.com"
    if not account.get("smtp_port"):
        account["smtp_port"] = 587

    # Ultra-natural subject and body — mimics a real 1:1 human email
    # Ultra-natural subject and body — mimics a genuine 1:1 direct email
    import random
    subjects = [
        "Quick hello from Alex",
        "Quick question regarding your setup",
        "Connecting / brief note",
        "Introduction & hello",
    ]
    openers = [
        "Hi there,\n\nHope you're having a great week so far.",
        "Hello,\n\nHope all is well on your side.",
        "Hi,\n\nWanted to send a quick note your way.",
    ]
    closers = [
        "Looking forward to staying in touch.\n\nBest regards,",
        "Would love to connect when you have a moment.\n\nAll the best,",
        "Have a great rest of your day.\n\nWarmly,",
    ]
    subject = random.choice(subjects)
    body = (
        f"{random.choice(openers)}\n\n"
        f"Just wanted to reach out directly to say hello and see how things are going with your current projects.\n\n"
        f"{random.choice(closers)}"
    )

    email_id = db.log_email(None, account["from_email"], to_email, subject, body, "quick_test", "queued")
    tracking_token = db.create_tracking_token(email_id)
    result = send_email_now(to_email, subject, body, account, tracking_token=tracking_token)
    elapsed = round((time.time() - start_t) * 1000, 1)
    result["elapsed_ms"] = elapsed
    if result.get("success"):
        db.mark_email_sent(email_id, result.get("message_id"), account["from_email"], provider=result.get("provider"))
        db.log_activity("test_email_sent", f"To: {to_email} | From: {account['from_email']} | Provider: {result.get('provider')}")
        notify_telegram_outbound(
            to_email=to_email,
            from_addr=account["from_email"],
            subject=subject,
            msg_type="Test Email"
        )
    else:
        db.mark_email_failed(email_id, result.get("error", "Test send error"))
    return result


def send_with_logging(lead_id: int, to_email: str, subject: str, body: str,
                      message_type: str = "opener", email_id: int = None,
                      from_account: str = None) -> dict:
    """
    Pick account → send → log result.
    If from_account is given or lead has starting account affinity, preserves the same sender account.
    Returns: {success, email_id, account_used, message_id, queued, error}
    """
    # 0. Zero-Bounce Pre-Send Verification Shield
    try:
        verify_res = email_verifier.verify_lead_email(to_email, deep_smtp=False)
        if not verify_res["valid"]:
            db.update_lead_stage(lead_id, "bounced")
            db.add_to_blacklist(to_email, reason=f"Zero-Bounce shield: {verify_res.get('reason')}")
            logger.warning(f"Zero-Bounce shield blocked invalid email: {to_email} ({verify_res.get('reason')})")
            return {
                "success": False,
                "error": f"Zero-Bounce shield blocked: {verify_res.get('reason')}",
                "bounce": True,
                "suppressed": True
            }
    except Exception as e:
        logger.debug(f"Pre-check bypassed on exception: {e}")

    # 1. Mailbox Selection with Thread Sender Affinity
    target_sender = (from_account or "").strip().lower()
    if not target_sender and lead_id and message_type != "opener":
        target_sender = (db.get_lead_starting_account(lead_id) or "").strip().lower()

    account = None
    if target_sender:
        account = outreach_engine.mailbox_pool.select_next_mailbox(preferred_email=target_sender)
        if not account:
            for a in db.get_all_accounts():
                if a["email"].lower() == target_sender:
                    account = dict(a)
                    break
        if account:
            logger.info(f"Preserving sender thread affinity: {account.get('email')} for lead #{lead_id}")

    if not account:
        account = outreach_engine.mailbox_pool.select_next_mailbox()
    if not account:
        account = db.get_next_available_account()

    if not account:
        # No capacity — just log as queued if not already logged
        if not email_id:
            email_id = db.log_email(lead_id, None, to_email, subject, body, message_type, "queued")
        return {
            "success": False,
            "queued": True,
            "email_id": email_id,
            "message": "All mailboxes at daily limit. Queued for tomorrow.",
        }

    # Normalize account dict (mailbox pool uses 'email', but send_email_now expects 'from_email')
    if account and "from_email" not in account:
        account["from_email"] = account.get("email", "")
        account["smtp_user"]  = account.get("smtp_user") or account.get("email", "")
        account["smtp_pass"]  = account.get("smtp_pass") or account.get("app_password", "")
        account["display_name"] = account.get("display_name") or account.get("label") or _make_display_name(account["from_email"])
        account["type"]       = account.get("type", "gmail")

    # Log as queued first (idempotent if already exists)
    if not email_id:
        email_id = db.log_email(lead_id, account["from_email"], to_email, subject, body, message_type, "queued")

    tracking_token = db.create_tracking_token(email_id)
    result = send_email_now(to_email, subject, body, account, tracking_token=tracking_token)

    # 2. Automatic Failover to backup mailbox if temporary SMTP rate-limit or auth failure
    if not result.get("success") and not result.get("bounce"):
        err_msg = result.get("error", "SMTP send error")
        outreach_engine.mailbox_pool.trigger_cooldown(account["from_email"], minutes=15, reason=err_msg)
        backup_account = outreach_engine.mailbox_pool.select_next_mailbox()
        if backup_account and backup_account["email"] != account["from_email"]:
            logger.info(f"Failing over dispatch from {account['from_email']} to backup {backup_account['email']}")
            result = send_email_now(to_email, subject, body, backup_account, tracking_token=tracking_token)
            if result.get("success"):
                account = backup_account

    if result["success"]:
        db.mark_email_sent(email_id, result.get("message_id"), account["from_email"], provider=result.get("provider"))
        db.add_conversation_message(lead_id, "us", f"[{message_type.upper()}] Subject: {subject}\n\n{body}")
        db.log_activity("email_sent", f"To: {to_email} | Type: {message_type} | From: {account['from_email']} | Provider: {result.get('provider')}")
        lead = db.get_lead(lead_id) if lead_id else None
        lead_name = lead.get("name") if lead else ""
        company = lead.get("company") if lead else ""
        notify_telegram_outbound(
            to_email=to_email,
            from_addr=account["from_email"],
            subject=subject,
            lead_name=lead_name,
            company=company,
            msg_type="Followup" if "followup" in message_type else "Campaign"
        )
        return {
            "success": True,
            "email_id": email_id,
            "account_used": result["account_used"],
            "message_id": result.get("message_id"),
        }
    else:
        db.mark_email_failed(email_id, result.get("error", "Unknown error"))
        db.log_activity("email_failed", f"To: {to_email} | Error: {result.get('error')}")
        return {
            "success": False,
            "email_id": email_id,
            "error": result.get("error"),
        }


def notify_telegram_outbound(to_email: str, from_addr: str, subject: str, lead_name: str = "", company: str = "", msg_type: str = "Campaign"):
    """
    Sends a compact Telegram notification to admin after an email is dispatched to a lead.
    Runs asynchronously in a background daemon thread so it never delays email queues or HTTP handlers.
    """
    def _send():
        try:
            import config
            import requests
            import html
            import re
            token = getattr(config, "TELEGRAM_BOT_TOKEN", "") or "8702594261:AAFiSqKkfanOJpxy5nhE-HmT-KNH3-xBk5c"
            uid = getattr(config, "ALLOWED_USER_ID", "") or 6642913680
            if not token or not uid:
                return

            clean_sub = (subject or "").strip()
            if len(clean_sub) > 60:
                clean_sub = clean_sub[:57] + "..."

            is_campaign = "campaign" in msg_type.lower() or msg_type in ("opener", "followup")
            icon = "🚀" if is_campaign else "✉️"
            type_label = "Campaign Email" if is_campaign else msg_type.title()

            lead_str = ""
            if lead_name and lead_name != to_email:
                esc_name = html.escape(str(lead_name))
                esc_comp = html.escape(str(company))
                lead_str = f"👤 <b>Lead:</b> {esc_name}" + (f" ({esc_comp})" if company else "") + "\n"
            elif company:
                esc_comp = html.escape(str(company))
                lead_str = f"🏢 <b>Company:</b> {esc_comp}\n"

            esc_sub = html.escape(clean_sub)
            esc_to = html.escape(str(to_email))
            esc_from = html.escape(str(from_addr))

            msg = (
                f"{icon} <b>{type_label} Dispatched!</b>\n"
                f"{lead_str}"
                f"📧 <b>To:</b> <code>{esc_to}</code>\n"
                f"📬 <b>From:</b> <code>{esc_from}</code>\n"
                f"📌 <b>Subject:</b> {esc_sub}"
            )

            resp = requests.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={
                    "chat_id": int(uid),
                    "text": msg,
                    "parse_mode": "HTML"
                },
                timeout=5
            )
            if resp.status_code != 200:
                clean_text = re.sub(r'<[^>]*>', '', msg)
                requests.post(
                    f"https://api.telegram.org/bot{token}/sendMessage",
                    json={
                        "chat_id": int(uid),
                        "text": clean_text
                    },
                    timeout=5
                )
        except Exception as e:
            logger.debug(f"Telegram notification ignored: {e}")

    threading.Thread(target=_send, daemon=True, name="TelegramOutboundAlert").start()


# ═══════════════════════════════════════════════════════════════
#                    PROXY SOCKET SUPPORT
# ═══════════════════════════════════════════════════════════════

def _make_smtp_connection(proxy_url: str | None, target_host: str = "mail.spacemail.com", target_port: int = 587, timeout: int = 6) -> smtplib.SMTP:
    """Create SMTP connection, optionally routed through a proxy, supporting both SSL (465) and STARTTLS (587)."""
    if not proxy_url:
        if target_port == 465:
            return smtplib.SMTP_SSL(target_host, target_port, timeout=timeout)
        return smtplib.SMTP(target_host, target_port, timeout=timeout)

    parsed = urlparse(proxy_url)
    scheme = (parsed.scheme or "").lower()

    if scheme in ("socks5", "socks5h", "socks4"):
        try:
            import socks

            proxy_type = socks.SOCKS5 if scheme.startswith("socks5") else socks.SOCKS4
            host = parsed.hostname
            port = parsed.port or 1080
            username = parsed.username
            password = parsed.password

            # Create a custom socket via PySocks
            sock = socks.create_connection(
                (target_host, target_port),
                proxy_type=proxy_type,
                proxy_addr=host,
                proxy_port=port,
                proxy_username=username,
                proxy_password=password,
                timeout=timeout,
            )
            if target_port == 465:
                import ssl
                context = ssl.create_default_context()
                sock = context.wrap_socket(sock, server_hostname=target_host)
                conn = smtplib.SMTP_SSL(timeout=timeout)
                conn.sock = sock
                conn._host = target_host
                return conn
            else:
                conn = smtplib.SMTP(timeout=timeout)
                conn.sock = sock
                conn._host = target_host
                return conn
        except ImportError:
            logger.warning("PySocks not installed — ignoring SOCKS proxy, falling back to direct connection.")
            return smtplib.SMTP_SSL(target_host, target_port, timeout=timeout) if target_port == 465 else smtplib.SMTP(target_host, target_port, timeout=timeout)
        except Exception as e_sock:
            logger.warning(f"SOCKS proxy connect to {host}:{port} failed ({e_sock}) — falling back to direct connection.")
            return smtplib.SMTP_SSL(target_host, target_port, timeout=timeout) if target_port == 465 else smtplib.SMTP(target_host, target_port, timeout=timeout)

    elif scheme in ("http", "https"):
        # HTTP proxy via CONNECT tunnel
        try:
            proxy_host = parsed.hostname
            proxy_port = parsed.port or 3128
            sock = _http_proxy_connect(proxy_host, proxy_port, target_host, target_port,
                                       parsed.username, parsed.password, timeout=timeout)
            if target_port == 465:
                import ssl
                context = ssl.create_default_context()
                sock = context.wrap_socket(sock, server_hostname=target_host)
                conn = smtplib.SMTP_SSL(timeout=timeout)
                conn.sock = sock
                conn._host = target_host
                return conn
            else:
                conn = smtplib.SMTP(timeout=timeout)
                conn.sock = sock
                conn._host = target_host
                return conn
        except Exception as e:
            logger.warning(f"HTTP proxy connect failed ({e}) — using direct connection")
            return smtplib.SMTP_SSL(target_host, target_port, timeout=timeout) if target_port == 465 else smtplib.SMTP(target_host, target_port, timeout=timeout)

    # Unknown scheme — direct
    return smtplib.SMTP_SSL(target_host, target_port, timeout=timeout) if target_port == 465 else smtplib.SMTP(target_host, target_port, timeout=timeout)


def _http_proxy_connect(proxy_host, proxy_port, target_host, target_port,
                        proxy_user=None, proxy_pass=None, timeout: int = 6):
    """Establish CONNECT tunnel through HTTP proxy."""
    sock = socket.create_connection((proxy_host, proxy_port), timeout=timeout)
    connect_str = f"CONNECT {target_host}:{target_port} HTTP/1.1\r\nHost: {target_host}:{target_port}\r\n"
    if proxy_user and proxy_pass:
        import base64
        creds = base64.b64encode(f"{proxy_user}:{proxy_pass}".encode()).decode()
        connect_str += f"Proxy-Authorization: Basic {creds}\r\n"
    connect_str += "\r\n"
    sock.sendall(connect_str.encode())

    response = b""
    while True:
        chunk = sock.recv(4096)
        response += chunk
        if b"\r\n\r\n" in response:
            break

    status_line = response.split(b"\r\n")[0].decode()
    if "200" not in status_line:
        sock.close()
        raise ConnectionError(f"HTTP proxy CONNECT failed: {status_line}")

    return sock


# ═══════════════════════════════════════════════════════════════
#                         HELPERS
# ═══════════════════════════════════════════════════════════════

def _make_display_name(email: str) -> str:
    """Derive clean human first name from email address (e.g. hannah@... -> Hannah, raifa@... -> Raifa)."""
    local = email.split("@")[0]
    name = re.sub(r"[._\-+]", " ", local).title().strip()
    first = name.split()[0] if name else "Flinza"
    return first


def test_account_connection(email: str, app_password: str, smtp_host: str = "mail.spacemail.com", smtp_port: int = 465) -> dict:
    """
    Quick SMTP auth test without sending. Returns {success, error}.

    Handles implicit-SSL relays (port 465, e.g. Spacemail or Namecheap Private
    Email) as well as STARTTLS relays (587 / 2525). Testing a 465 relay through
    the old STARTTLS-only path always failed, even with perfect credentials.
    """
    try:
        port = int(smtp_port or 465)
        if port == 465:
            with smtplib.SMTP_SSL(smtp_host, port, timeout=6) as server:
                server.ehlo()
                server.login(email, app_password)
        else:
            with smtplib.SMTP(smtp_host, port, timeout=6) as server:
                server.ehlo()
                server.starttls()
                server.ehlo()
                server.login(email, app_password)
        return {"success": True}
    except smtplib.SMTPAuthenticationError:
        return {"success": False, "error": f"Authentication failed for {email} on {smtp_host}. Check credentials."}
    except Exception as e:
        return {"success": False, "error": str(e)}


def test_imap_connection(email: str, password: str, imap_host: str = "mail.spacemail.com", imap_port: int = 993) -> dict:
    """Quick IMAP auth test without modifying anything. Returns {success, error}."""
    try:
        with imaplib.IMAP4_SSL(imap_host, int(imap_port or 993), timeout=6) as mail:
            mail.login(email, password)
        return {"success": True}
    except imaplib.IMAP4.error as e:
        return {"success": False, "error": f"IMAP login rejected for {email} on {imap_host}: {e}"}
    except Exception as e:
        return {"success": False, "error": str(e)}
