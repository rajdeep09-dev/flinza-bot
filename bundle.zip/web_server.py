"""
Flinza — Enterprise Outreach Web Studio Server
FastAPI application providing REST APIs, Open/Click tracking handlers,
Google OAuth2 callback processing, and serving the Studio Single-Page Application.
"""

import os
import json
import html
import logging
import secrets
import tempfile
import threading
import asyncio
import time
import csv
import io
import math
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr, make_msgid, formatdate
from datetime import datetime, date
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse
import httpx
from fastapi import FastAPI, Request, Response, Query, Form, UploadFile, File, BackgroundTasks, HTTPException, Depends
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
import uvicorn

import config
import database as db
import email_sender
import email_queue
import reply_watcher
import followup_scheduler
import cloudflare_aliases
import ai_router
import email_toolkit
import google_auth
import signature_generator
import tracking_server
import outreach_engine
import email_verifier

logger = logging.getLogger(__name__)

def mask_credentials(data: dict) -> dict:
    """Masks sensitive credentials before returning in API responses."""
    clean = dict(data)
    for key in ["app_password", "smtp_pass", "custom_smtp_pass", "password", "cf_api_token"]:
        if clean.get(key):
            clean[key] = "••••••••••••"
    return clean

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

# ── Auto-generate dashboard key if not set ────────────────────────
_api_key = config.DASHBOARD_API_KEY
if not _api_key:
    _api_key = secrets.token_hex(24)
    logger.warning("="*60)
    logger.warning("⚠️  DASHBOARD_API_KEY not set in .env — generated a one-time key:")
    logger.warning(f"    KEY: {_api_key}")
    logger.warning("    Add to .env: DASHBOARD_API_KEY=%s" % _api_key)
    logger.warning("    Then set it in the dashboard login prompt.")
    logger.warning("="*60)

# ─────────────────────────────────────────────────────────────────
#   ALLOWED SETTINGS KEYS (whitelist — reject unknown keys)
# ─────────────────────────────────────────────────────────────────
ALLOWED_SETTING_KEYS = {
    "sender_name", "sender_email", "reply_to_email", "daily_limit",
    "min_interval", "max_interval", "followup_days", "max_followups",
    "reply_check_minutes", "reply_check_seconds", "auto_reply_mode", "system_prompt",
    "tracking_base_url", "studio_port", "cf_api_token", "cf_account_id",
    "cf_zone_id", "cf_domain", "google_client_id", "google_client_secret",
    "google_redirect_uri", "inbound_webhook_secret",
    "gemini_api_key", "groq_api_key", "mistral_api_key",
    "nvidia_api_key", "openrouter_api_key",
    "smtp_batch_size", "smtp_batch_rotation_enabled", "smtp_batch_active_provider",
    "ses_sent_today", "ses_daily_limit", "ses_quota_exceeded_today",
    "signature_name", "signature_title", "signature_email",
    "signature_phone", "signature_website", "signature_company",
    "bounce_rate_guard_enabled", "bounce_rate_guard_threshold",
    "sla_tracker_enabled", "sla_tracker_hours",
    "backup_enabled", "backup_retention_days",
}

app = FastAPI(
    title="Flinza Works Outreach Studio",
    description="Enterprise Cold Email Outreach & Agency Studio",
    version="2.0.0",
    docs_url=None,     # Disabled for security — enable via ENABLE_API_DOCS=true
    redoc_url=None,
    openapi_url=None,
)

from json.decoder import JSONDecodeError

@app.exception_handler(JSONDecodeError)
async def json_decode_error_handler(request: Request, exc: JSONDecodeError):
    return JSONResponse(
        status_code=400,
        content={"success": False, "error": "Invalid or malformed JSON payload"}
    )

# ── Security Headers Middleware ───────────────────────────────────
class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://fonts.gstatic.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "img-src 'self' data: https:; "
            "connect-src 'self';"
        )
        return response

app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.ALLOWED_ORIGINS,
    allow_origin_regex=r"https://.*\.onrender\.com|https://.*\.flinzaworks\.(site|online)",
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD"],
    allow_headers=["*"],
)

# Static files and templates
os.makedirs(STATIC_DIR / "css", exist_ok=True)
os.makedirs(STATIC_DIR / "js", exist_ok=True)
os.makedirs(TEMPLATES_DIR, exist_ok=True)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


# ─────────────────────────────────────────────────────────────────
#   AUTHENTICATION DEPENDENCY
# ─────────────────────────────────────────────────────────────────
async def verify_api_key(request: Request):
    """Bearer token / cookie auth guard for all /api/* routes."""
    if not config.REQUIRE_AUTH:
        return True

    # Cloudflare Inbound Webhook authenticates via X-Webhook-Secret
    if request.url.path.startswith("/api/webhooks/inbound"):
        secret = request.headers.get("x-webhook-secret", "")
        expected = config.INBOUND_WEBHOOK_SECRET or db.get_setting("inbound_webhook_secret", "")
        if expected and secret and secrets.compare_digest(secret, expected):
            return True

    # Check session cookie
    cookie_token = request.cookies.get("flinza_session")
    if cookie_token and secrets.compare_digest(cookie_token, _api_key):
        return True

    auth_header = request.headers.get("Authorization", "")
    token = ""
    if auth_header.startswith("Bearer "):
        token = auth_header[7:].strip()
    elif request.headers.get("X-API-Key"):
        token = request.headers.get("X-API-Key").strip()
    elif request.query_params.get("api_key"):
        token = request.query_params.get("api_key").strip()

    if not token or not secrets.compare_digest(token, _api_key):
        raise HTTPException(
            status_code=401,
            detail="Unauthorized: Invalid or missing credentials. Please log in.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return True

_auth = Depends(verify_api_key)


# ═══════════════════════════════════════════════════════════════
#                    AUTHENTICATION ENDPOINTS
# ═══════════════════════════════════════════════════════════════

@app.post("/api/auth/login")
async def auth_login(request: Request, response: Response):
    """Authenticates with hardcoded credentials and returns session token + sets cookie."""
    try:
        body = await request.json()
    except Exception:
        body = {}
    email = (body.get("email") or "").strip().lower()
    password = (body.get("password") or "").strip()

    expected_email = config.DASHBOARD_LOGIN_EMAIL.lower().strip()
    expected_pass = config.DASHBOARD_LOGIN_PASSWORD.strip()
    valid_emails = {
        expected_email,
        "rajdeep@flinzaconsuslting.com",
        "rajdeep@flinzaconsulting.com",
        "rajdeep@flinzamedia.com",
        "admin@flinzamedia.com"
    }

    # Guard: an unset login or password must never authenticate. Otherwise an
    # empty expected_pass would make compare_digest("", "") succeed for anyone.
    is_direct_key = bool(password) and secrets.compare_digest(
        password.encode("utf-8"), str(_api_key).encode("utf-8")
    )
    is_valid_cred = bool(expected_pass) and (
        email in valid_emails
        and secrets.compare_digest(password.encode("utf-8"), expected_pass.encode("utf-8"))
    )

    if not (is_valid_cred or is_direct_key):
        raise HTTPException(status_code=401, detail="Invalid email or password.")

    response.set_cookie(
        key="flinza_session",
        value=_api_key,
        max_age=86400 * 30,
        httponly=False,
        samesite="lax",
        secure=request.url.scheme == "https"
    )
    return {
        "success": True,
        "token": _api_key,
        "email": config.DASHBOARD_LOGIN_EMAIL,
        "message": "Authenticated successfully"
    }


@app.post("/api/auth/logout")
async def auth_logout(response: Response):
    """Logs out user and clears session cookie."""
    response.delete_cookie(key="flinza_session")
    return {"success": True, "message": "Logged out"}


@app.get("/api/auth/status")
async def auth_status(request: Request):
    """Returns session authentication status."""
    cookie_token = request.cookies.get("flinza_session")
    auth_header = request.headers.get("Authorization", "")
    token = ""
    if auth_header.startswith("Bearer "):
        token = auth_header[7:].strip()
    elif cookie_token:
        token = cookie_token
    elif request.headers.get("X-API-Key"):
        token = request.headers.get("X-API-Key").strip()

    is_auth = bool(token and secrets.compare_digest(token, _api_key))
    return {
        "authenticated": is_auth,
        "email": config.DASHBOARD_LOGIN_EMAIL if is_auth else None,
        "dashboard_url": config.DASHBOARD_PUBLIC_URL
    }


# ═══════════════════════════════════════════════════════════════
#                    SPA DASHBOARD ROUTE
# ═══════════════════════════════════════════════════════════════

@app.api_route("/", methods=["GET", "HEAD"], response_class=HTMLResponse)
async def index_page(request: Request):
    """Serves the main Flinza Studio application shell."""
    cookie_token = request.cookies.get("flinza_session")
    is_logged_in = bool(cookie_token and secrets.compare_digest(cookie_token, _api_key))
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "app_name": "Flinza Studio",
            "dashboard_api_key": _api_key,
            "dashboard_url": config.DASHBOARD_PUBLIC_URL,
            "login_email": config.DASHBOARD_LOGIN_EMAIL,
            "is_logged_in": is_logged_in
        }
    )


# Health check endpoint (no auth — for uptime monitoring)
@app.api_route("/health", methods=["GET", "HEAD"])
async def health_check():
    """System health check for uptime monitoring (Render, UptimeRobot, etc.)."""
    db_ok = False
    sent_today = 0
    try:
        conn = db.get_db()
        conn.execute("SELECT 1").fetchone()
        conn.close()
        db_ok = True
    except Exception as e:
        logger.warning(f"Health DB ping warning: {e}")

    try:
        stats = db.get_stats()
        sent_today = stats.get("sent_today", 0)
    except Exception as e:
        logger.warning(f"Health stats warning (non-fatal): {e}")

    is_running = False
    try:
        is_running = email_queue.is_running()
    except Exception:
        pass

    return {
        "status": "ok" if db_ok else "degraded",
        "version": "2.2.0",
        "db": "ok" if db_ok else "error",
        "queue": "running" if is_running else "idle",
        "sent_today": sent_today,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }


# ═══════════════════════════════════════════════════════════════
#             EMAIL TRACKING (OPENS & CLICKS)
# ═══════════════════════════════════════════════════════════════

@app.get("/t/o/{token}.png")
async def track_open_pixel(token: str, request: Request):
    """Serves 1x1 transparent GIF/PNG and records email open event."""
    user_agent = request.headers.get("user-agent", "")
    client_ip = request.client.host if request.client else ""
    png_bytes = tracking_server.handle_open(token, user_agent=user_agent, ip=client_ip)
    return Response(content=png_bytes, media_type="image/png", headers={"Cache-Control": "no-cache, no-store, must-revalidate"})


@app.get("/t/c/{token}")
async def track_click_redirect(token: str, target: str = Query(default=""), request: Request = None):
    """Records link click event and redirects to destination URL."""
    user_agent = request.headers.get("user-agent", "") if request else ""
    client_ip = request.client.host if request and request.client else ""
    dest_url = tracking_server.handle_click(token, target, user_agent=user_agent, ip=client_ip)
    # HIGH-03 fix: validate redirect target to prevent open redirect abuse
    if dest_url:
        parsed = urlparse(dest_url)
        if parsed.scheme not in ("http", "https"):
            return Response(status_code=400, content="Invalid redirect target")
    return RedirectResponse(url=dest_url or "https://flinzaworks.online", status_code=302)


# ═══════════════════════════════════════════════════════════════
#             GOOGLE OAUTH2 AUTHENTICATION
# ═══════════════════════════════════════════════════════════════

@app.get("/auth/google/login")
async def google_login():
    """Generates Google OAuth2 consent URL and redirects the user."""
    url = google_auth.get_google_auth_url()
    if not url:
        return JSONResponse(
            {"error": "Google Client ID is not configured. Set it in settings or .env"},
            status_code=400,
        )
    return RedirectResponse(url=url)


@app.get("/auth/google/callback")
async def google_callback(code: Optional[str] = None, error: Optional[str] = None):
    """Handles OAuth callback and exchanges code for access & refresh tokens."""
    if error:
        safe_error = html.escape(str(error))  # XSS fix: HTML-escape user-controlled string
        return HTMLResponse(f"<h3>Google OAuth Failed</h3><p>{safe_error}</p><a href='/'>Return to Studio</a>")
    if not code:
        return HTMLResponse("<h3>Missing authorization code</h3><a href='/'>Return to Studio</a>")

    res = google_auth.exchange_code_for_tokens(code)
    if res.get("success"):
        safe_email = html.escape(str(res.get('email', '')))
        return HTMLResponse(
            f"""<html><body style="font-family:system-ui;background:#0f111a;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;">
            <div style="background:#1a1d2d;padding:40px;border-radius:12px;border:1px solid #313752;text-align:center;">
                <h2 style="color:#10b981;margin-top:0;">&#x2705; Google Account Connected!</h2>
                <p>Connected email: <b>{safe_email}</b></p>
                <p style="color:#94a3b8;">Flinza can now dispatch emails via Gmail REST API.</p>
                <a href="/" style="display:inline-block;margin-top:20px;padding:10px 24px;background:#6366f1;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;">Open Flinza Studio</a>
            </div>
            <script>setTimeout(function(){{ window.location.href = '/'; }}, 2500);</script>
            </body></html>"""
        )
    safe_err = html.escape(str(res.get('error', 'Unknown error')))
    return HTMLResponse(f"<h3>OAuth Exchange Error</h3><p>{safe_err}</p><a href='/'>Return</a>")


# ═══════════════════════════════════════════════════════════════
#                      REST API ENDPOINTS
# ═══════════════════════════════════════════════════════════════

@app.get("/api/stats", dependencies=[_auth])
async def get_dashboard_stats():
    """Returns overview statistics, delivery metrics, pipeline breakdown, and queue status."""
    stats = db.get_stats()
    tracking = db.get_tracking_stats()
    pipeline = db.get_pipeline_breakdown()
    warmup = db.get_warmup_status()
    is_q_running = email_queue.is_running()
    is_q_paused = email_queue.is_paused()

    return {
        "success": True,
        "stats": stats,
        "tracking": tracking,
        "pipeline": pipeline,
        "warmup": warmup,
        "queue_status": "paused" if is_q_paused else ("running" if is_q_running else "idle"),
    }


@app.get("/api/leads", dependencies=[_auth])
async def list_leads(
    stage: Optional[str] = None,
    search: Optional[str] = None,
    crm_priority: Optional[str] = None,
    niche: Optional[str] = None,
    country: Optional[str] = None,
    revenue: Optional[str] = None,
    company_size: Optional[str] = None,
    icp_fit: Optional[str] = None,
    deliverability_status: Optional[str] = None,
    sort: Optional[str] = None,
    limit: int = 500,
):
    """Returns advanced filtered leads list."""
    prio_val = None
    if crm_priority is not None and str(crm_priority) != "" and str(crm_priority) != "all":
        try:
            prio_val = int(crm_priority)
        except ValueError:
            pass

    leads = db.get_leads(
        stage=stage if stage and stage != "all" else None,
        search=search,
        crm_priority=prio_val,
        niche=niche,
        country=country,
        revenue=revenue,
        company_size=company_size,
        icp_fit=icp_fit,
        deliverability_status=deliverability_status,
        sort_by=sort or "crm_priority_asc",
        limit=limit,
    )
    return {"success": True, "count": len(leads), "leads": [dict(l) for l in leads]}


@app.post("/api/leads/bulk", dependencies=[_auth])
async def bulk_action_leads(request: Request):
    """Bulk operations on selected leads (delete, set_priority, set_stage, set_niche, blacklist)."""
    body = await request.json()
    ids = body.get("ids", [])
    action = body.get("action", "")
    val = body.get("value")
    res = db.bulk_update_leads(ids, action, val)
    return res


@app.patch("/api/leads/{lead_id}", dependencies=[_auth])
@app.put("/api/leads/{lead_id}", dependencies=[_auth])
async def update_lead_endpoint(lead_id: int, request: Request):
    """Updates fields on an individual lead (priority tier, stage, niche, etc.)."""
    body = await request.json()
    allowed = ["name", "email", "company", "niche", "website", "linkedin", "stage",
               "tier", "notes", "custom_hook", "crm_priority", "country", "revenue",
               "company_size", "icp_fit", "sub_niche", "contact_title",
               "ai_subject", "ai_draft", "personalized_icebreaker"]
    sets = []
    vals = []
    for k in allowed:
        if k in body:
            sets.append(f"{k}=?")
            vals.append(body[k])
    if not sets:
        raise HTTPException(status_code=400, detail="No valid fields to update")
    vals.append(lead_id)
    conn = db.get_db()
    conn.execute(f"UPDATE leads SET {','.join(sets)} WHERE id=?", vals)
    conn.commit()
    conn.close()
    return {"success": True, "id": lead_id}


@app.get("/api/leads/filter-options", dependencies=[_auth])
async def get_filter_options_endpoint():
    """Returns distinct options for CRM filter dropdowns."""
    return db.get_leads_filter_options()


@app.post("/api/leads", dependencies=[_auth])
async def add_or_update_lead(request: Request):
    """Add a new lead to database."""
    body = await request.json()
    email = body.get("email", "").strip()
    if not email or "@" not in email:
        raise HTTPException(status_code=400, detail="Valid email is required")

    lead_id = db.add_lead(
        email=email,
        name=body.get("name", "").strip(),
        handle=body.get("handle", "").strip(),
        niche=body.get("niche", "").strip(),
        tier=body.get("tier", "medium"),
        notes=body.get("notes", "").strip(),
        company=body.get("company", "").strip(),
        website=body.get("website", "").strip(),
    )
    return {"success": True, "lead_id": lead_id}


@app.delete("/api/leads/{lead_id}", dependencies=[_auth])
async def delete_lead(lead_id: int):
    """Deletes a lead from the CRM."""
    db.delete_lead(lead_id)
    return {"success": True, "deleted_id": lead_id}


@app.post("/api/leads/import", dependencies=[_auth])
async def import_leads_csv(file: UploadFile = File(...)):
    """Uploads and imports a CSV file of leads."""
    content = await file.read()
    # HIGH-04 fix: Never use user-supplied filename; use secure tempfile
    if len(content) > 10 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="File too large. Maximum 10 MB allowed.")
    import leads_importer
    with tempfile.NamedTemporaryFile(suffix=".csv", dir=str(BASE_DIR), delete=False) as tmp:
        tmp.write(content)
        tmp_path = tmp.name
    result = leads_importer.import_csv(tmp_path)
    try:
        os.remove(tmp_path)
    except Exception:
        pass
    return {"success": True, "result": result}


@app.get("/api/leads/export", dependencies=[_auth])
async def export_leads():
    """Exports leads as CSV string."""
    csv_str = db.export_leads_csv()
    return Response(
        content=csv_str,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=flinza_leads.csv"},
    )


@app.get("/api/leads/sample-csv", dependencies=[_auth])
async def download_sample_leads_csv():
    """Returns a perfectly formatted sample CSV file with high-converting AI personalization headers."""
    sample_rows = [
        ["first_name", "last_name", "email", "company", "niche", "website", "linkedin", "custom_hook"],
        ["Sarah", "Connor", "sarah@apexmedia.co", "Apex Media", "E-Commerce", "https://apexmedia.co", "https://linkedin.com/in/sarahconnor", "Loved your recent TikTok series on DTC ad scaling"],
        ["Marcus", "Vance", "marcus@hypergrowth.io", "HyperGrowth", "B2B SaaS", "https://hypergrowth.io", "https://linkedin.com/in/marcusvance", "Saw your Product Hunt #1 launch last Tuesday"],
        ["Elena", "Rostova", "elena@fitlabpro.com", "FitLab Pro", "Fitness App", "https://fitlabpro.com", "https://linkedin.com/in/elenarostova", "Your IG reels retention is great but missing short-form hook variations"],
        ["David", "Chen", "david@nexustech.ai", "Nexus Tech", "AI Software", "https://nexustech.ai", "https://linkedin.com/in/davidchen", "Noticed your founder teardown video on LinkedIn last week"],
        ["Olivia", "Taylor", "olivia@voguehaven.shop", "Vogue Haven", "Fashion DTC", "https://voguehaven.shop", "https://linkedin.com/in/oliviataylor", "Your Meta creative could easily 3x with creator whitelisting"],
    ]
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerows(sample_rows)
    csv_content = output.getvalue()

    return Response(
        content=csv_content,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=flinza_sample_leads_template.csv"}
    )


@app.post("/api/leads/upload-csv", dependencies=[_auth])
async def upload_leads_csv(request: Request, file: Optional[UploadFile] = File(None)):
    """Imports leads from CSV with support for custom_hook and linkedin columns for AI hyper-personalization."""
    csv_text = ""
    if file:
        content = await file.read()
        # MED-05 fix: limit upload size to 10 MB
        if len(content) > 10 * 1024 * 1024:
            raise HTTPException(status_code=413, detail="File too large. Maximum 10 MB allowed.")
        csv_text = content.decode("utf-8", errors="replace")
    else:
        try:
            body_json = await request.json()
            csv_text = body_json.get("csv_text", "")
            if len(csv_text) > 10 * 1024 * 1024:
                raise HTTPException(status_code=413, detail="CSV text too large. Maximum 10 MB.")
        except HTTPException:
            raise
        except Exception:
            pass

    if not csv_text.strip():
        raise HTTPException(status_code=400, detail="Empty CSV content provided")

    reader = csv.DictReader(io.StringIO(csv_text))
    imported_count = 0
    updated_count = 0
    imported_leads = []

    for row in reader:
        # Normalize keys (strip whitespace, lowercase)
        norm_row = {k.strip().lower(): v.strip() for k, v in row.items() if k}
        email = norm_row.get("email", "")
        if not email or "@" not in email:
            continue

        # Extract name
        first_name = norm_row.get("first_name", "")
        last_name = norm_row.get("last_name", "")
        name = norm_row.get("name", "")
        if not name and (first_name or last_name):
            name = f"{first_name} {last_name}".strip()

        company = norm_row.get("company") or norm_row.get("brand") or norm_row.get("organization") or ""
        niche = norm_row.get("niche") or norm_row.get("industry") or norm_row.get("category") or "General B2B"
        website = norm_row.get("website") or norm_row.get("url") or ""
        linkedin = norm_row.get("linkedin") or norm_row.get("linkedin_url") or ""
        custom_hook = norm_row.get("custom_hook") or norm_row.get("hook") or norm_row.get("icebreaker") or norm_row.get("notes") or ""

        lead_id = db.add_or_update_lead(
            name=name or "Founder",
            email=email,
            company=company,
            niche=niche,
            website=website,
            linkedin=linkedin,
            custom_hook=custom_hook,
            stage="new"
        )
        imported_count += 1
        imported_leads.append({"id": lead_id, "name": name, "email": email, "company": company, "custom_hook": custom_hook})

    return {"success": True, "imported_count": imported_count, "leads": imported_leads}


@app.post("/api/leads/{lead_id}/ai-draft", dependencies=[_auth])
async def generate_lead_ai_draft(lead_id: int, request: Request = None):
    """Generates or saves custom AI hyper-personalized cold outreach subject & body for this specific lead."""
    lead = db.get_lead_by_id(lead_id)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")

    sub, body = None, None
    if request:
        try:
            payload = await request.json()
            if isinstance(payload, dict):
                sub = payload.get("ai_subject") or payload.get("subject")
                body = payload.get("ai_draft") or payload.get("body")
        except Exception:
            pass

    if sub and body:
        # Sanitize em dashes/en dashes
        sub = str(sub).replace("—", " - ").replace("–", " - ").strip()
        body = str(body).replace(" — ", ", ").replace("—", ", ").replace(" – ", " - ").replace("–", " - ").strip()
        db.update_lead_ai_draft(lead_id, sub, body)
        return {"success": True, "lead_id": lead_id, "ai_subject": sub, "ai_draft": body, "saved_manual": True}

    opener = ai_router.generate_opener(lead)
    sub = opener.get("subject", f"Quick idea for {lead.get('company', 'your team')}")
    body = opener.get("body", "")

    db.update_lead_ai_draft(lead_id, sub, body)
    return {"success": True, "lead_id": lead_id, "ai_subject": sub, "ai_draft": body, "used_fallback": opener.get("used_fallback", False)}


@app.post("/api/leads/generate-ai-batch", dependencies=[_auth])
async def generate_ai_drafts_batch():
    """Generates hyper-personalized AI drafts for all new leads that lack custom drafts."""
    leads = db.get_leads(stage="new", limit=100)
    generated = 0
    for l in leads:
        lead = dict(l)
        if not lead.get("ai_draft"):
            opener = ai_router.generate_opener(lead)
            db.update_lead_ai_draft(lead["id"], opener.get("subject"), opener.get("body"))
            generated += 1
    return {"success": True, "generated_count": generated, "total_leads": len(leads)}


@app.get("/api/templates", dependencies=[_auth])
async def get_templates_endpoint():
    """Returns all master outreach email templates."""
    conn = db.get_db()
    rows = conn.execute("SELECT id, name, type, subject, body FROM templates ORDER BY id ASC").fetchall()
    conn.close()
    result = []
    for r in rows:
        result.append({
            "id": r["id"],
            "name": r["name"],
            "type": r["type"],
            "subject": r["subject"],
            "body": r["body"]
        })
    return {"success": True, "templates": result}


@app.put("/api/templates/{template_id}", dependencies=[_auth])
@app.post("/api/templates/{template_id}", dependencies=[_auth])
async def update_template_endpoint(template_id: int, request: Request):
    """Updates a master outreach email template."""
    data = await request.json()
    subject = (data.get("subject") or "").strip()
    body = (data.get("body") or "").strip()
    name = (data.get("name") or "").strip()
    if not subject or not body:
        raise HTTPException(status_code=400, detail="Subject and body are required")

    # Sanitize any em/en dashes
    subject = subject.replace("—", " - ").replace("–", " - ")
    body = body.replace(" — ", ", ").replace("—", ", ").replace(" – ", " - ").replace("–", " - ")

    conn = db.get_db()
    if name:
        conn.execute("UPDATE templates SET name=?, subject=?, body=? WHERE id=?", (name, subject, body, template_id))
    else:
        conn.execute("UPDATE templates SET subject=?, body=? WHERE id=?", (subject, body, template_id))
    conn.commit()
    conn.close()
    return {"success": True, "id": template_id, "subject": subject, "body": body}


@app.post("/api/templates/apply-bulk", dependencies=[_auth])
async def apply_template_bulk(request: Request):
    """Applies a chosen template to all leads in stage 'new' (or specified lead IDs)."""
    data = await request.json()
    template_id = data.get("template_id")
    lead_ids = data.get("lead_ids")

    conn = db.get_db()
    tmpl = conn.execute("SELECT * FROM templates WHERE id=?", (template_id,)).fetchone()
    if not tmpl:
        conn.close()
        raise HTTPException(status_code=404, detail="Template not found")

    query = "SELECT * FROM leads WHERE stage='new'"
    params = []
    if lead_ids and isinstance(lead_ids, list) and len(lead_ids) > 0:
        placeholders = ','.join('?' for _ in lead_ids)
        query = f"SELECT * FROM leads WHERE id IN ({placeholders})"
        params = lead_ids

    leads = conn.execute(query, params).fetchall()
    updated_count = 0
    import populate_real_leads_and_templates as pop

    for l in leads:
        lead_dict = dict(l)
        first_name = (lead_dict.get("name") or "there").split()[0]
        company = lead_dict.get("company") or "your brand"
        niche = lead_dict.get("niche") or "DTC Brand"
        followers = lead_dict.get("instagram_followers") or 0
        order_lift, rev_lift = pop.get_lifts_by_niche_and_revenue(niche, followers)
        icebreaker = lead_dict.get("personalized_icebreaker") or lead_dict.get("custom_hook") or f"Loved what {company} is doing, your creative direction and product positioning really stand out."

        rendered_subj, rendered_body = pop.render_email_template(
            {"subject": tmpl["subject"], "body": tmpl["body"]},
            first_name, company, icebreaker, order_lift, rev_lift
        )
        conn.execute("UPDATE leads SET ai_subject=?, ai_draft=? WHERE id=?", (rendered_subj, rendered_body, lead_dict["id"]))
        updated_count += 1

    conn.commit()
    conn.close()
    return {"success": True, "updated_count": updated_count}


@app.post("/api/leads/generate-and-queue", dependencies=[_auth])
async def generate_and_queue_all_leads(request: Request):
    """
    1-Click: Generates 100% unique AI hyper-personalized emails for all new leads
    and stages them into the outbound sending queue ready for campaign launch.
    """
    try:
        b = await request.json()
    except Exception:
        b = {}
    stage = b.get("stage", "new")
    campaign_id = int(b.get("campaign_id", 1))
    force_ai = b.get("force_ai", False)

    leads = [dict(l) for l in db.get_leads(stage=stage if stage != "all" else None, limit=500)]
    if not leads and stage != "all":
        # Fallback to any uncontacted leads
        all_leads = [dict(l) for l in db.get_leads(stage=None, limit=500)]
        leads = [l for l in all_leads if l.get("stage") in ("new", None, "")]

    if not leads:
        return {"success": False, "message": "No uncontacted leads found in Leads CRM to queue."}

    accounts = [dict(a) for a in db.get_all_accounts() if dict(a).get("active", 1)]
    if not accounts:
        return {"success": False, "message": "No active sending mailboxes found. Connect a Gmail or SMTP account first."}

    queued_count = 0
    skipped_count = 0
    generated_pitches = 0

    for idx, lead in enumerate(leads):
        email = (lead.get("email") or "").strip()
        if not email or "@" not in email:
            skipped_count += 1
            continue

        if db.is_blacklisted(email) or email_toolkit.is_disposable_email(email):
            skipped_count += 1
            continue

        if db.email_already_queued_or_sent(email):
            skipped_count += 1
            continue

        subject = (lead.get("ai_subject") or "").strip()
        body = (lead.get("ai_draft") or "").strip()

        if not subject or not body:
            sender_name = db.get_setting("sender_name", "Flinza")
            steps = db.get_sequence_steps(campaign_id) or []
            if steps and steps[0].get("body_a"):
                import hashlib
                s1 = steps[0]
                seed = int(hashlib.md5(email.encode()).hexdigest(), 16) % 10000
                subject, body = outreach_engine.personalize(
                    s1.get("subject_a", ""),
                    s1.get("body_a", ""),
                    lead=lead,
                    sender_name=sender_name,
                    seed=seed
                )
            else:
                first_name = lead.get("first_name") or (lead.get("name", "").split()[0] if lead.get("name") else "there")
                company = lead.get("company") or "your team"
                niche = lead.get("niche") or "growth"
                subject = f"Quick question regarding {company}"
                body = f"Hey {first_name},\n\nHope you're having a great week.\n\nNoticed what you're doing with {company} in the {niche} space and saw a few untapped opportunities to scale customer acquisition with short-form video.\n\nWould you be open to a quick 2-minute video breakdown of how we've helped similar brands?\n\nBest,\n{sender_name}"

            db.update_lead_ai_draft(lead["id"], subject, body)
            generated_pitches += 1

        account = accounts[idx % len(accounts)]
        from_email = account.get("from_email") or account.get("email")

        db.queue_email(
            lead_id=lead["id"],
            from_account=from_email,
            to_email=email,
            subject=subject,
            body=body,
            step_number=1,
            campaign_id=campaign_id,
            priority=1,
            message_type="opener"
        )
        db.update_lead_stage(lead["id"], "contacted")
        queued_count += 1

    stats = db.get_stats()
    return {
        "success": True,
        "queued_count": queued_count,
        "generated_pitches": generated_pitches,
        "skipped_count": skipped_count,
        "total_queued": stats.get("queued", stats.get("queued_count", queued_count)),
        "message": f"⚡ Generated {generated_pitches} AI pitches & queued {queued_count} emails into campaign!"
    }


@app.post("/api/leads/{lead_id}/verify-deep", dependencies=[_auth])
async def verify_single_lead_deep(lead_id: int):
    """Executes a deep Zero-Bounce deliverability check on a single lead (MX, Catch-All, Disposable, Syntax)."""
    lead = db.get_lead_by_id(lead_id)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")

    result = email_verifier.verify_lead_deliverability(lead["email"], deep_smtp=True)
    db.update_lead_deliverability(
        lead_id=lead_id,
        status=result["status"],
        score=result["score"],
        details_json=json.dumps(result)
    )
    return {"success": True, "lead_id": lead_id, "audit": result}


@app.post("/api/leads/verify-all-deep", dependencies=[_auth])
async def verify_all_leads_deep():
    """Runs full Zero-Bounce MX & Catch-All audit on all new leads, updating badges and filtering dead mailboxes."""
    leads = db.get_leads(stage="new", limit=300)
    clean_cnt = 0
    catchall_cnt = 0
    dead_cnt = 0

    for l in leads:
        ld = dict(l)
        res = email_verifier.verify_lead_deliverability(ld["email"], deep_smtp=False)
        db.update_lead_deliverability(ld["id"], res["status"], res["score"], json.dumps(res))
        if not res["valid"]:
            db.update_lead_stage(ld["id"], "bounced")
            dead_cnt += 1
        elif res["is_catch_all"]:
            catchall_cnt += 1
            clean_cnt += 1
        else:
            clean_cnt += 1

    return {
        "success": True,
        "scanned": len(leads),
        "clean_count": clean_cnt,
        "catchall_count": catchall_cnt,
        "dead_count": dead_cnt
    }


@app.get("/api/accounts", dependencies=[_auth])
async def get_accounts_fleet():
    """Returns list of all Gmail master inboxes, OAuth accounts, and domain aliases."""
    raw_accounts = db.get_all_accounts()
    raw_aliases = db.get_all_aliases()
    oauth_accs = db.get_all_oauth_accounts()
    oauth_map = {o["account_email"].lower(): True for o in oauth_accs}

    accounts = []
    for a in raw_accounts:
        d = dict(a)
        d["is_oauth"] = bool(oauth_map.get(d["email"].lower()))
        accounts.append(d)

    aliases = [dict(al) for al in raw_aliases]

    return {
        "success": True,
        "accounts": accounts,
        "aliases": aliases,
        "total_inboxes": len(accounts),
        "total_aliases": len(aliases),
    }


@app.post("/api/accounts", dependencies=[_auth])
async def create_account(request: Request):
    """Adds a Gmail account or alias."""
    body = await request.json()
    acct_type = body.get("type", "gmail")

    if acct_type == "alias":
        alias = body.get("alias", "").strip().lower()
        smtp_user = body.get("smtp_user", "").strip().lower()
        smtp_pass = body.get("smtp_pass", "").strip()
        disp = body.get("display_name", "")
        db.add_alias(alias, smtp_user, smtp_pass, display_name=disp, source="manual")
        return {"success": True, "created": alias}
    else:
        email = body.get("email", "").strip().lower()
        password = body.get("app_password", "").strip()
        limit = int(body.get("daily_limit", 50))
        db.add_account(email, password, daily_limit=limit)
        return {"success": True, "created": email}


@app.delete("/api/accounts/{account_id}", dependencies=[_auth])
async def delete_account_by_id(account_id: int):
    """Deletes an account from fleet."""
    db.remove_account(account_id)
    return {"success": True, "deleted_id": account_id}


@app.post("/api/accounts/cloudflare", dependencies=[_auth])
async def add_cf_sending_account(request: Request):
    """Adds a Cloudflare Email Sending account ($5/mo Workers Paid plan)."""
    b = await request.json()
    from_email = b.get("from_email", "").strip().lower()
    daily_limit = int(b.get("daily_limit", 100))
    label = b.get("label") or "Cloudflare Native API"
    if not from_email:
        raise HTTPException(status_code=400, detail="from_email is required")
    ok = db.add_cloudflare_sending_account(from_email, daily_limit=daily_limit, label=label)
    return {"success": ok, "account": from_email, "provider": "cloudflare_api"}


@app.post("/api/accounts/amazon-ses", dependencies=[_auth])
async def add_ses_sending_account(request: Request):
    """Adds an Amazon SES SMTP sending account."""
    b = await request.json()
    from_email = b.get("from_email", "").strip().lower()
    smtp_user = b.get("smtp_user", "").strip()
    smtp_pass = b.get("smtp_pass", "").strip()
    smtp_host = b.get("smtp_host") or config.AWS_SES_SMTP_HOST
    smtp_port = int(b.get("smtp_port") or 587)
    daily_limit = int(b.get("daily_limit", 200))
    label = b.get("label") or "Amazon SES"

    if not from_email or not smtp_user or not smtp_pass:
        raise HTTPException(status_code=400, detail="from_email, smtp_user, and smtp_pass are required")

    ok = db.add_amazon_ses_account(
        from_email=from_email,
        smtp_user=smtp_user,
        smtp_pass=smtp_pass,
        smtp_host=smtp_host,
        smtp_port=smtp_port,
        daily_limit=daily_limit,
        label=label
    )
    return {"success": ok, "account": from_email, "provider": "amazon_ses"}


def _sender_first_name(email_addr: str) -> str:
    local = email_addr.split("@")[0]
    return local.split(".")[0].split("_")[0].capitalize()


@app.get("/api/accounts/next-sender", dependencies=[_auth])
async def get_next_sender():
    """Returns the first name of the next available mailbox in the pool."""
    conn = db.get_db()
    row = conn.execute("""
        SELECT email FROM gmail_accounts
        WHERE active=1
        AND COALESCE(sent_today, 0) < COALESCE(daily_limit, 50)
        ORDER BY COALESCE(last_used, '1970-01-01') ASC
        LIMIT 1
    """).fetchone()
    conn.close()
    if not row:
        return {"success": False, "first_name": "Flinza"}
    first_name = _sender_first_name(row["email"])
    return {"success": True, "first_name": first_name, "email": row["email"]}


@app.get("/api/settings/sending-hours", dependencies=[_auth])
async def get_sending_hours():
    conn = db.get_db()
    row = conn.execute("SELECT value FROM settings WHERE key='sending_hours'").fetchone()
    conn.close()
    if row:
        return {"success": True, "sending_hours": json.loads(row[0])}
    defaults = {
        "US": {"start": "09:00", "end": "18:00", "timezone": "America/New_York", "enabled": True},
        "UK": {"start": "09:00", "end": "17:30", "timezone": "Europe/London",   "enabled": True},
        "UAE": {"start": "10:00", "end": "17:00", "timezone": "Asia/Dubai",     "enabled": True},
        "AU": {"start": "09:00", "end": "17:00", "timezone": "Australia/Sydney","enabled": True},
        "CA": {"start": "09:00", "end": "18:00", "timezone": "America/Toronto", "enabled": True},
        "IN": {"start": "10:00", "end": "19:00", "timezone": "Asia/Kolkata",    "enabled": True},
        "default": {"start": "09:00", "end": "18:00", "timezone": "UTC",        "enabled": True},
    }
    return {"success": True, "sending_hours": defaults}


@app.post("/api/settings/sending-hours", dependencies=[_auth])
async def save_sending_hours(request: Request):
    body = await request.json()
    hours = body.get("sending_hours", {})
    conn = db.get_db()
    conn.execute(
        "INSERT OR REPLACE INTO settings (key, value) VALUES ('sending_hours', ?)",
        (json.dumps(hours),)
    )
    conn.commit()
    conn.close()
    return {"success": True}


@app.post("/api/accounts/test", dependencies=[_auth])
async def test_account_creds(request: Request):
    """Tests authentication or sends a live test email with failover and dynamic signature."""
    body = await request.json()
    to_email = body.get("to_email")
    account_email = body.get("email")

    if not to_email:
        # Credential test only
        pwd = body.get("password")
        host = body.get("smtp_host")
        port = body.get("smtp_port")
        if not pwd and account_email:
            conn = db.get_db()
            row = conn.execute("SELECT * FROM gmail_accounts WHERE email=?", (account_email,)).fetchone()
            conn.close()
            if row:
                acc_row = dict(row)
                pwd = acc_row.get("smtp_pass") or acc_row.get("app_password")
                if not host:
                    host = acc_row.get("smtp_host") or "mail.spacemail.com"
                if not port:
                    port = acc_row.get("smtp_port") or 587
        host = host or "mail.spacemail.com"
        port = int(port or 587)
        res = await asyncio.to_thread(email_sender.test_account_connection, account_email, pwd, smtp_host=host, smtp_port=port)
        return res

    # Live test send requested
    conn = db.get_db()
    if account_email:
        row = conn.execute(
            "SELECT * FROM gmail_accounts WHERE email=? AND active=1",
            (account_email,)
        ).fetchone()
    else:
        row = conn.execute("""
            SELECT * FROM gmail_accounts
            WHERE active=1
            AND COALESCE(sent_today, 0) < COALESCE(daily_limit, 50)
            ORDER BY COALESCE(last_used, '1970-01-01') ASC
            LIMIT 1
        """).fetchone()
    conn.close()

    if not row:
        return {"success": False, "error": "No active mailbox with capacity found"}

    acc = dict(row)
    email_addr = acc["email"]
    password = acc.get("smtp_pass") or acc.get("app_password")
    smtp_host = acc.get("smtp_host") or "mail.spacemail.com"
    smtp_port = int(acc.get("smtp_port") or 587)

    sender_first = _sender_first_name(email_addr)
    display_name = sender_first
    custom_subject = body.get("subject")
    custom_body = body.get("body")

    if custom_body:
        import re as _re
        custom_body = _re.sub(r'\bRajdeep\b', sender_first, custom_body)

    msg = MIMEMultipart("alternative")
    msg["From"] = formataddr((display_name, email_addr))
    msg["To"] = to_email
    msg["Subject"] = custom_subject or f"✅ Test Email from {email_addr}"
    msg["Date"] = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid(domain=email_addr.split("@")[-1])

    body_text = custom_body or (
        f"This is a live test email sent from the Flinza outreach system.\n\n"
        f"Sender: {display_name} <{email_addr}>\n"
        f"SMTP: {smtp_host}:{smtp_port}\n\n"
        f"✅ Sending pipeline is working!\n\n— {sender_first}\nFlinza Media"
    )
    msg.attach(MIMEText(body_text, "plain", "utf-8"))

    msg_str = msg.as_string()
    msg_id = msg["Message-ID"]
    msg_subj = msg["Subject"]
    now_ts = datetime.now().isoformat()

    # Pre-insert into emails_sent immediately so Sent folder reflects it instantly
    conn2 = db.get_db()
    conn2.execute(
        """INSERT INTO emails_sent (from_account, to_email, subject, body, status, message_id, sent_at, provider)
           VALUES (?, ?, ?, ?, 'sent', ?, ?, 'spacemail')""",
        (email_addr, to_email, msg_subj, body_text, msg_id, now_ts)
    )
    conn2.execute(
        "UPDATE gmail_accounts SET last_used=?, sent_today=COALESCE(sent_today,0)+1 WHERE email=?",
        (now_ts, email_addr)
    )
    conn2.commit()
    conn2.close()

    def _send_sync():
        if smtp_port == 465:
            with smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=6) as server:
                server.ehlo()
                server.login(email_addr, password)
                server.sendmail(email_addr, [to_email], msg_str)
        else:
            with smtplib.SMTP(smtp_host, smtp_port, timeout=6) as server:
                server.ehlo()
                server.starttls()
                server.ehlo()
                server.login(email_addr, password)
                server.sendmail(email_addr, [to_email], msg_str)

        try:
            db.log_activity("test_send", f"To: {to_email} | From: {email_addr}")
        except Exception:
            pass
        email_sender.notify_telegram_outbound(
            to_email=to_email,
            from_addr=email_addr,
            subject=msg_subj,
            msg_type="Test Email"
        )
        return True

    start_t = time.time()
    try:
        await asyncio.wait_for(asyncio.to_thread(_send_sync), timeout=2.2)
        return {
            "success": True,
            "from": email_addr,
            "sender_name": sender_first,
            "to": to_email,
            "message_id": msg_id,
            "smtp": f"{smtp_host}:{smtp_port}",
            "elapsed_ms": round((time.time() - start_t) * 1000)
        }
    except asyncio.TimeoutError:
        return {
            "success": True,
            "status": "dispatched",
            "from": email_addr,
            "sender_name": sender_first,
            "to": to_email,
            "message_id": msg_id,
            "smtp": f"{smtp_host}:{smtp_port}",
            "message": f"🚀 Test email dispatched from {email_addr}...",
            "elapsed_ms": round((time.time() - start_t) * 1000)
        }
    except Exception as e:
        logger.error(f"Test send error for {email_addr}: {e}")
        return {"success": False, "error": f"{email_addr}: {str(e)}"}


# ── Inbound Email Webhook (Cloudflare Routing Worker) ──────────
@app.post("/api/webhooks/inbound", dependencies=[_auth])
async def inbound_email_webhook(request: Request):
    """
    Receives incoming emails forwarded by the Cloudflare Email Routing Worker.
    Validates secret, updates lead status, runs AI intent classification,
    generates suggested reply draft, and pushes instant alert to Telegram.
    """
    secret = request.headers.get("x-webhook-secret", "")
    expected_secret = config.INBOUND_WEBHOOK_SECRET or db.get_setting("inbound_webhook_secret", "")

    if expected_secret and secret != expected_secret:
        raise HTTPException(status_code=401, detail="Invalid webhook secret")

    body = await request.json()
    from_email = body.get("from", "").strip()
    to_email   = body.get("to", "").strip()
    subject    = body.get("subject", "")
    content    = body.get("body", "")

    if not from_email:
        raise HTTPException(status_code=400, detail="Missing 'from' email address")

    # 1. Log inbound reply to database
    reply_id, lead = db.log_inbound_webhook_reply(
        from_email=from_email,
        to_email=to_email,
        subject=subject,
        body=content
    )

    if not reply_id:
        return {"status": "ignored_duplicate", "from": from_email}

    # 2. AI Intent Classification & Draft Generation
    import email_toolkit
    intent_data = email_toolkit.classify_reply_intent(subject, content)
    intent = intent_data.get("intent", "general_reply")
    sentiment = intent_data.get("sentiment", "neutral")
    is_unsub = intent_data.get("is_unsubscribe", False)

    if is_unsub:
        db.handle_unsubscribe(from_email, reason="inbound_reply_unsubscribe")

    draft_body = ""
    draft_subj = f"Re: {subject}"
    if not is_unsub:
        try:
            instruction_hint = f"Lead intent is {intent}. {intent_data.get('suggested_action', '')}"
            conversation = db.get_conversation(lead["id"])
            draft = ai_router.generate_reply_draft(
                lead_info=dict(lead),
                conversation=conversation,
                their_reply=content,
                instruction=instruction_hint
            )
            draft_body = draft.get("body", "")
            draft_subj = draft.get("subject", draft_subj)
        except Exception as e:
            logger.error(f"Error generating AI reply draft for {reply_id}: {e}")

    db.update_reply_draft(reply_id, draft_subj, draft_body)
    conn = db.get_db()
    conn.execute("UPDATE replies SET intent=?, sentiment=? WHERE id=?", (intent, sentiment, reply_id))
    conn.commit()
    conn.close()

    # 3. Trigger instant Telegram Push Notification
    try:
        import bot
        bot.notify_telegram({
            "type": "inbound_reply",
            "reply_id": reply_id,
            "lead_id": lead.get("id"),
            "lead_name": lead.get("name") or "Lead",
            "from_email": from_email,
            "to_email": to_email,
            "subject": subject,
            "body": content,
            "ai_draft_body": draft_body,
            "intent": intent,
            "is_unsubscribe": (intent == "unsubscribe")
        })
    except Exception as e:
        logger.warning(f"Telegram notification error: {e}")

    return {
        "success": True,
        "reply_id": reply_id,
        "lead_id": lead.get("id"),
        "intent": intent
    }


# ── Cloudflare Studio Endpoints ────────────────────────────────
@app.get("/api/cloudflare/zones", dependencies=[_auth])
async def get_cf_zones():
    """Discovers all active zones on the user's Cloudflare account."""
    zones = cloudflare_aliases.list_user_zones()
    current_domain = db.get_setting("cf_domain") or config.CF_DOMAIN
    return {"success": True, "zones": zones, "current_domain": current_domain}


@app.post("/api/cloudflare/audit", dependencies=[_auth])
async def audit_dns(request: Request):
    """Deep DNS audit for SPF, DKIM, DMARC, and MX records."""
    body = await request.json()
    domain = body.get("domain") or db.get_setting("cf_domain") or config.CF_DOMAIN
    if not domain:
        raise HTTPException(status_code=400, detail="Domain name is required")
    res = cloudflare_aliases.audit_domain_dns(domain)
    return {"success": True, "audit": res}


@app.post("/api/cloudflare/generate", dependencies=[_auth])
async def generate_cf_aliases(request: Request):
    """Auto-generates 5 agency aliases and binds them to master Gmail."""
    body = await request.json()
    master = body.get("master_email")
    if not master:
        accs = db.get_all_accounts()
        if not accs:
            raise HTTPException(status_code=400, detail="Add at least one master Gmail account first")
        master = accs[0]["email"]

    count = int(body.get("count", 5))
    created = cloudflare_aliases.create_multiple_aliases(master, count=count)
    return {"success": True, "created": created}


# ── Campaign Sequences Endpoints ──────────────────────────────
@app.get("/api/sequences", dependencies=[_auth])
async def get_sequences(campaign_id: int = 1):
    """Returns sequence steps for campaign."""
    steps = db.get_campaign_sequences(campaign_id)
    return {"success": True, "steps": steps}


@app.post("/api/sequences", dependencies=[_auth])
async def save_sequence(request: Request):
    """Creates a sequence step."""
    body = await request.json()
    sid = db.save_sequence_step(
        campaign_id=int(body.get("campaign_id", 1)),
        step_number=int(body.get("step_number", 1)),
        delay_days=int(body.get("delay_days", 3)),
        condition_type=body.get("condition_type", "always"),
        subject_a=body.get("subject_a", ""),
        body_a=body.get("body_a", ""),
        subject_b=body.get("subject_b"),
        body_b=body.get("body_b"),
    )
    return {"success": True, "sequence_id": sid}


@app.delete("/api/sequences/{sequence_id}", dependencies=[_auth])
async def delete_sequence(sequence_id: int):
    """Deletes a sequence step."""
    db.delete_sequence_step(sequence_id)
    return {"success": True, "deleted_id": sequence_id}


# ── Unibox (Unified Inbox) Endpoints ──────────────────────────
@app.get("/api/unibox", dependencies=[_auth])
async def get_unibox_replies():
    """Returns all unhandled incoming replies with AI drafts."""
    replies = db.get_unhandled_replies()
    return {"success": True, "replies": replies}


@app.post("/api/unibox/reply", dependencies=[_auth])
async def send_unibox_reply(request: Request):
    """Dispatches reply draft to lead, strictly maintaining starting sender account affinity."""
    body = await request.json()
    raw_reply_id = body.get("reply_id")
    if not raw_reply_id:
        raise HTTPException(status_code=400, detail="Missing reply_id")
    try:
        reply_id = int(raw_reply_id)
    except (ValueError, TypeError):
        raise HTTPException(status_code=400, detail="Invalid reply_id format")

    custom_text = body.get("body")
    conn = db.get_db()
    rep = conn.execute("SELECT * FROM replies WHERE id=?", (reply_id,)).fetchone()
    conn.close()

    if not rep:
        raise HTTPException(status_code=404, detail="Reply not found")

    text_to_send = custom_text or rep["ai_draft_body"] or ""
    lead = db.get_lead(rep["lead_id"]) if rep["lead_id"] else None
    orig_subj = rep["subject"] or "Inquiry"
    subj = f"Re: {orig_subj}" if not orig_subj.lower().startswith("re:") else orig_subj

    # Maintain strict thread affinity: send from the exact account where the lead sent their message
    target_from = (rep["to_email"] or "").strip().lower() if rep["to_email"] else None
    if not target_from and rep["lead_id"]:
        target_from = db.get_lead_starting_account(rep["lead_id"])

    def _do_reply():
        return email_sender.send_with_logging(
            lead_id=rep["lead_id"],
            to_email=rep["from_email"],
            subject=subj,
            body=text_to_send,
            message_type="negotiation_reply",
            from_account=target_from,
        )

    start = time.time()
    try:
        res = await asyncio.wait_for(asyncio.to_thread(_do_reply), timeout=10.0)
        if res.get("success"):
            db.mark_reply_handled(reply_id)
            res["elapsed_ms"] = round((time.time() - start) * 1000)
            return {"success": True, "result": res, "account_used": res.get("account_used") or target_from}
        return {"success": False, "error": res.get("error")}
    except asyncio.TimeoutError:
        db.mark_reply_handled(reply_id)
        return {
            "success": True,
            "status": "dispatched",
            "message": f"🚀 Reply dispatched via {target_from or 'Spacemail SSL'}!",
            "account_used": target_from,
            "elapsed_ms": round((time.time() - start) * 1000)
        }


@app.get("/api/webmail/threads/{thread_id}/conversation", dependencies=[_auth])
async def get_thread_conversation(thread_id: int):
    """
    Returns the complete, chronological back-and-forth conversation thread
    for the selected email (all outbound emails and inbound replies).
    """
    thread_data = db.get_conversation_thread(reply_id=thread_id)
    return {"success": True, **thread_data}


_last_unibox_check = 0.0

@app.post("/api/unibox/check", dependencies=[_auth])
async def poll_inboxes():
    """Fires IMAP inbox check across mailboxes and waits for completion so UI instantly updates."""
    global _last_unibox_check
    now = time.time()
    if now - _last_unibox_check < 3.0:
        return {"success": True, "message": "Inbox sync already recently completed."}
    _last_unibox_check = now

    try:
        new_replies = await asyncio.wait_for(asyncio.to_thread(reply_watcher.check_now), timeout=12.0)
        return {
            "success": True,
            "message": f"Inbox sync complete ({len(new_replies)} new message{'s' if len(new_replies) != 1 else ''} fetched).",
            "new_count": len(new_replies)
        }
    except asyncio.TimeoutError:
        return {"success": True, "message": "Inbox sync running in background…"}
    except Exception as e:
        logger.error(f"Inbox check error: {e}")
        return {"success": False, "error": str(e)}


def _query_webmail_threads(conn, folder: str, search: Optional[str], filter: str, page: int, limit: int):
    threads = []

    # Filter out noisy automated system senders/alerts from primary leads inbox
    system_filter_sql = """
        AND r.from_email NOT LIKE '%no-reply%'
        AND r.from_email NOT LIKE '%noreply%'
        AND r.from_email NOT LIKE '%google.com%'
        AND r.from_email NOT LIKE '%apify.com%'
        AND r.from_email NOT LIKE '%mailer-daemon%'
        AND r.from_email NOT LIKE '%cloudflare.com%'
        AND r.from_email NOT LIKE '%brevo.com%'
        AND r.from_email NOT LIKE '%verify%'
        AND r.from_email NOT LIKE '%notification%'
        AND LOWER(r.subject) NOT LIKE '%verify%'
        AND LOWER(r.subject) NOT LIKE '%verification%'
        AND LOWER(r.subject) NOT LIKE '%otp%'
        AND LOWER(r.subject) NOT LIKE '%security alert%'
        AND LOWER(r.subject) NOT LIKE '%usage exceeded%'
        AND LOWER(r.subject) NOT LIKE '%confirm%'
    """

    # Check if replies is empty (e.g. freshly booted container on cloud host)
    all_inbox_cnt = conn.execute("SELECT COUNT(*) as c FROM replies").fetchone()["c"]
    if all_inbox_cnt == 0:
        try:
            import reply_watcher
            reply_watcher.check_now()
            all_inbox_cnt = conn.execute("SELECT COUNT(*) as c FROM replies").fetchone()["c"]
        except Exception as e_sync:
            logger.warning(f"Auto-sync on zero inboxes: {e_sync}")

    # Folder Counts: inbox = leads & direct human inquiries; all_inboxes = every incoming email
    leads_inbox_cnt = conn.execute(f"""
        SELECT COUNT(*) as c FROM replies r 
        LEFT JOIN leads l ON r.lead_id = l.id 
        WHERE (r.lead_id IS NOT NULL OR (COALESCE(r.sentiment, '') != 'bounced' AND COALESCE(r.intent, '') != 'bounced'))
          {system_filter_sql}
    """).fetchone()["c"]
    starred_cnt = conn.execute("SELECT (SELECT COUNT(*) FROM replies WHERE is_starred=1) + (SELECT COUNT(*) FROM emails_sent WHERE is_starred=1) as c").fetchone()["c"]
    drafts_cnt = conn.execute("SELECT COUNT(*) as c FROM replies WHERE handled=0 AND ai_draft_body IS NOT NULL").fetchone()["c"]
    sent_cnt = conn.execute("SELECT COUNT(*) as c FROM emails_sent WHERE status='sent'").fetchone()["c"]
    spam_cnt = conn.execute("SELECT COUNT(*) as c FROM blacklist").fetchone()["c"]

    offset = max(0, (page - 1) * limit)
    total_count = 0

    if folder in ("inbox", "all-inboxes", "all_inboxes"):
        base_where = []
        params = []
        if folder == "inbox":
            # Primary Inbox: show lead replies and real human inbound messages
            if filter == "needs_reply":
                base_where.append("r.handled = 0")
            elif filter == "replied":
                base_where.append("(r.handled = 1 OR l.stage = 'replied' OR r.action_taken LIKE '%sent%')")

            base_where.append("(r.lead_id IS NOT NULL OR (COALESCE(r.sentiment, '') != 'bounced' AND COALESCE(r.intent, '') != 'bounced'))")
            base_where.append("r.from_email NOT LIKE '%no-reply%'")
            base_where.append("r.from_email NOT LIKE '%noreply%'")
            base_where.append("r.from_email NOT LIKE '%google.com%'")
            base_where.append("r.from_email NOT LIKE '%apify.com%'")
            base_where.append("r.from_email NOT LIKE '%mailer-daemon%'")
            base_where.append("r.from_email NOT LIKE '%cloudflare.com%'")
            base_where.append("r.from_email NOT LIKE '%brevo.com%'")
            base_where.append("r.from_email NOT LIKE '%verify%'")
            base_where.append("r.from_email NOT LIKE '%notification%'")
            base_where.append("LOWER(r.subject) NOT LIKE '%verify%'")
            base_where.append("LOWER(r.subject) NOT LIKE '%verification%'")
            base_where.append("LOWER(r.subject) NOT LIKE '%otp%'")
            base_where.append("LOWER(r.subject) NOT LIKE '%security alert%'")
            base_where.append("LOWER(r.subject) NOT LIKE '%usage exceeded%'")
            base_where.append("LOWER(r.subject) NOT LIKE '%confirm%'")

        if filter == "interested":
            base_where.append("(r.sentiment = 'positive' OR r.intent IN ('interested', 'rate_inquiry'))")
        elif filter == "replied" and folder != "inbox":
            base_where.append("(r.handled = 1 OR l.stage = 'replied' OR r.sentiment != 'bounced')")
        elif filter == "needs_reply" and folder != "inbox":
            base_where.append("r.handled = 0")
        elif filter == "bounced":
            base_where.append("(r.sentiment = 'bounced' OR r.intent = 'bounced')")
        elif filter == "unread":
            base_where.append("r.is_read = 0")

        if search:
            base_where.append("(r.from_email LIKE ? OR r.subject LIKE ? OR r.body LIKE ?)")
            s = f"%{search}%"
            params.extend([s, s, s])

        where_clause = (" WHERE " + " AND ".join(base_where)) if base_where else ""
        count_query = f"SELECT COUNT(*) as c FROM replies r LEFT JOIN leads l ON r.lead_id = l.id {where_clause}"
        total_count = conn.execute(count_query, params).fetchone()["c"]

        query = f"""
            SELECT r.id, r.lead_id, r.from_email as sender, r.to_email, r.action_taken, r.subject, r.body,
                   r.received_at as timestamp, r.sentiment, r.intent, r.ai_draft_subject, r.ai_draft_body,
                   r.handled, r.is_read, r.is_starred, l.name as lead_name, l.company as lead_company
            FROM replies r
            LEFT JOIN leads l ON r.lead_id = l.id
            {where_clause}
            ORDER BY r.id DESC LIMIT ? OFFSET ?
        """
        rows = conn.execute(query, params + [limit, offset]).fetchall()
        for r in rows:
            is_lead = bool(r["lead_id"])
            intent = r["intent"] or "Inbound"
            subj_lower = (r["subject"] or "").lower()
            sender_lower = (r["sender"] or "").lower()
            is_verification = any(k in subj_lower or k in sender_lower for k in ["verify", "verification", "activate", "confirm", "render", "otp", "security code"])

            tag = "Inbound"
            if is_lead:
                if r["handled"] == 1:
                    tag = "Replied"
                elif intent in ("interested", "rate_inquiry"):
                    tag = "Interested"
                elif intent == "unsubscribe":
                    tag = "Opt-Out"
                elif intent == "bounced":
                    tag = "Bounced"
                else:
                    tag = "Needs Reply"
            elif is_verification:
                tag = "Verification"
            else:
                tag = "Mailbox"

            lead_display = r["lead_name"] or (r["sender"].split("@")[0].title() if r["sender"] else "there")
            clean_subj = (r["subject"] or "").replace("Re: ", "").replace("RE: ", "").replace("re: ", "")
            draft_sub = r["ai_draft_subject"] or (f"Re: {clean_subj}" if (clean_subj and is_lead) else None)
            draft_body = r["ai_draft_body"] or (f"Hi {lead_display},\n\nThanks for reaching back out! Great to hear from you. Let's set up a quick 15-minute chat this week to run through the details.\n\nDoes Thursday or Friday afternoon work for you?\n\nBest regards,\nAlex Vance" if is_lead else None)

            recip = r["to_email"]
            if not recip and r["action_taken"] and str(r["action_taken"]).startswith("inbound_to_"):
                recip = str(r["action_taken"]).replace("inbound_to_", "")
            if not recip:
                recip = "Primary Inbox"

            threads.append({
                "id": r["id"],
                "lead_id": r["lead_id"],
                "type": "inbound",
                "sender": r["sender"],
                "recipient": recip,
                "starting_account": recip,
                "subject": r["subject"] or "(No Subject)",
                "snippet": (r["body"] or "").replace("\n", " ")[:140],
                "body": r["body"] or "",
                "ai_draft_subject": draft_sub,
                "ai_draft_body": draft_body,
                "timestamp": r["timestamp"],
                "tag": tag,
                "handled": bool(r["handled"] == 1),
                "unread": bool(r["is_read"] == 0),
                "is_starred": bool(r["is_starred"] == 1),
                "lead_name": r["lead_name"],
                "lead_company": r["lead_company"]
            })

    elif folder == "starred":
        base_where = ["r.is_starred = 1"]
        params = []
        if search:
            base_where.append("(r.from_email LIKE ? OR r.subject LIKE ? OR r.body LIKE ?)")
            s = f"%{search}%"
            params.extend([s, s, s])
        where_clause = " WHERE " + " AND ".join(base_where)
        total_count = conn.execute(f"SELECT COUNT(*) as c FROM replies r {where_clause}", params).fetchone()["c"]
        query = f"""
            SELECT r.id, r.from_email as sender, r.to_email, r.action_taken, r.subject, r.body,
                   r.received_at as timestamp, r.sentiment, r.intent, r.ai_draft_subject, r.ai_draft_body,
                   r.handled, r.is_read, r.is_starred, l.name as lead_name, l.company as lead_company
            FROM replies r
            LEFT JOIN leads l ON r.lead_id = l.id
            {where_clause}
            ORDER BY r.id DESC LIMIT ? OFFSET ?
        """
        rows = conn.execute(query, params + [limit, offset]).fetchall()
        for r in rows:
            recip = r["to_email"]
            if not recip and r["action_taken"] and str(r["action_taken"]).startswith("inbound_to_"):
                recip = str(r["action_taken"]).replace("inbound_to_", "")
            if not recip:
                recip = "Primary Inbox"

            threads.append({
                "id": r["id"],
                "type": "inbound",
                "sender": r["sender"],
                "recipient": recip,
                "subject": r["subject"] or "(No Subject)",
                "snippet": (r["body"] or "").replace("\n", " ")[:140],
                "body": r["body"] or "",
                "ai_draft_subject": r["ai_draft_subject"] or "Re: Quick Followup",
                "ai_draft_body": r["ai_draft_body"] or "Hi,\n\nFollowing up on our conversation.",
                "timestamp": r["timestamp"],
                "tag": "Starred",
                "unread": bool(r["is_read"] == 0),
                "is_starred": True,
                "lead_name": r["lead_name"],
                "lead_company": r["lead_company"]
            })

    elif folder == "sent":
        base_where = ["e.status = 'sent'"]
        params = []
        if search:
            base_where.append("(e.to_email LIKE ? OR e.subject LIKE ? OR e.body LIKE ?)")
            s = f"%{search}%"
            params.extend([s, s, s])
        where_clause = " WHERE " + " AND ".join(base_where)
        total_count = conn.execute(f"SELECT COUNT(*) as c FROM emails_sent e {where_clause}", params).fetchone()["c"]
        query = f"""
            SELECT e.id, e.from_account as sender, e.to_email as recipient, e.subject, e.body,
                   e.sent_at as timestamp, e.status, e.is_starred, COALESCE(t.open_count, 0) as open_count, COALESCE(t.click_count, 0) as click_count
            FROM emails_sent e
            LEFT JOIN email_tracking t ON e.id = t.email_id
            {where_clause}
            ORDER BY e.sent_at DESC LIMIT ? OFFSET ?
        """
        rows = conn.execute(query, params + [limit, offset]).fetchall()
        for r in rows:
            tag = "Sent"
            if (r["click_count"] or 0) > 0:
                tag = "Clicked"
            elif (r["open_count"] or 0) > 0:
                tag = "Opened"
            threads.append({
                "id": r["id"],
                "type": "outbound",
                "sender": r["sender"] or "Outreach Bot",
                "recipient": r["recipient"],
                "subject": r["subject"] or "(No Subject)",
                "snippet": (r["body"] or "").replace("\n", " ")[:140],
                "body": r["body"] or "",
                "timestamp": r["timestamp"],
                "tag": tag,
                "unread": False,
                "is_starred": bool(r["is_starred"] == 1)
            })

    elif folder == "drafts":
        base_where = ["r.handled = 0 AND r.ai_draft_body IS NOT NULL"]
        params = []
        if search:
            base_where.append("(r.from_email LIKE ? OR r.subject LIKE ? OR r.ai_draft_body LIKE ?)")
            s = f"%{search}%"
            params.extend([s, s, s])
        where_clause = " WHERE " + " AND ".join(base_where)
        total_count = conn.execute(f"SELECT COUNT(*) as c FROM replies r {where_clause}", params).fetchone()["c"]
        query = f"""
            SELECT r.id, r.from_email as sender, r.subject, r.ai_draft_body as body,
                   r.received_at as timestamp, r.is_starred
            FROM replies r
            {where_clause}
            ORDER BY r.id DESC LIMIT ? OFFSET ?
        """
        rows = conn.execute(query, params + [limit, offset]).fetchall()
        for r in rows:
            threads.append({
                "id": r["id"],
                "type": "draft",
                "sender": "AI Negotiation Engine",
                "recipient": r["from_email"],
                "subject": f"Re: {r['subject'] or ''}",
                "snippet": (r["body"] or "").replace("\n", " ")[:140],
                "body": r["body"] or "",
                "timestamp": r["timestamp"],
                "tag": "AI Draft",
                "unread": False,
                "is_starred": bool(r["is_starred"] == 1)
            })

    elif folder == "spam":
        base_where = []
        params = []
        if search:
            base_where.append("(email LIKE ? OR domain LIKE ? OR reason LIKE ?)")
            s = f"%{search}%"
            params.extend([s, s, s])
        where_clause = (" WHERE " + " AND ".join(base_where)) if base_where else ""
        total_count = conn.execute(f"SELECT COUNT(*) as c FROM blacklist {where_clause}", params).fetchone()["c"]
        rows = conn.execute(
            f"SELECT id, email, domain, reason, added_at as timestamp FROM blacklist {where_clause} ORDER BY added_at DESC LIMIT ? OFFSET ?",
            params + [limit, offset]
        ).fetchall()
        for r in rows:
            threads.append({
                "id": r["id"],
                "type": "spam",
                "sender": r["email"] or r["domain"] or "Blacklisted",
                "recipient": "Flinza",
                "subject": f"Suppressed / Blacklisted: {r['reason'] or 'Manual'}",
                "snippet": f"Reason: {r['reason']} | Added: {r['timestamp']}",
                "body": f"Address {r['email']} suppressed due to: {r['reason']}",
                "timestamp": r["timestamp"],
                "tag": "Spam",
                "unread": False,
                "is_starred": False
            })

    total_pages = max(1, math.ceil(total_count / limit)) if total_count > 0 else 1
    return {
        "success": True,
        "folder": folder,
        "filter": filter,
        "page": page,
        "limit": limit,
        "total_count": total_count,
        "total_pages": total_pages,
        "counts": {
            "inbox": leads_inbox_cnt,
            "all_inboxes": all_inbox_cnt,
            "starred": starred_cnt,
            "drafts": drafts_cnt,
            "sent": sent_cnt,
            "spam": spam_cnt
        },
        "threads": threads
    }


# ── Webmail & Priority Inbox Endpoints (Mailflare Style) ──────
@app.get("/api/webmail/threads", dependencies=[_auth])
async def get_webmail_threads(
    folder: str = "inbox",
    search: Optional[str] = None,
    filter: str = "all",
    page: int = 1,
    limit: int = 25
):
    """
    Returns threads for the Mailflare Webmail UI:
    folder: inbox (leads only) | all-inboxes | starred | sent | drafts | spam
    filter: all | interested | replied | bounced | unread
    page: 1-indexed (pagination)
    limit: items per page (default 25)
    """
    conn = db.get_db()
    try:
        return _query_webmail_threads(conn, folder, search, filter, page, limit)
    finally:
        conn.close()

@app.post("/api/webmail/threads/{thread_id}/star", dependencies=[_auth])
async def toggle_webmail_star(thread_id: int):
    """Toggles the is_starred status of a thread."""
    conn = db.get_db()
    row = conn.execute("SELECT is_starred FROM replies WHERE id = ?", (thread_id,)).fetchone()
    if row:
        new_val = 0 if row["is_starred"] == 1 else 1
        conn.execute("UPDATE replies SET is_starred = ? WHERE id = ?", (new_val, thread_id))
        conn.commit()
        conn.close()
        return {"success": True, "is_starred": bool(new_val == 1)}

    row_sent = conn.execute("SELECT is_starred FROM emails_sent WHERE id = ?", (thread_id,)).fetchone()
    if row_sent:
        new_val = 0 if row_sent["is_starred"] == 1 else 1
        conn.execute("UPDATE emails_sent SET is_starred = ? WHERE id = ?", (new_val, thread_id))
        conn.commit()
        conn.close()
        return {"success": True, "is_starred": bool(new_val == 1)}

    conn.close()
    return {"success": False, "error": "Thread not found"}


@app.post("/api/webmail/threads/{thread_id}/read", dependencies=[_auth])
async def mark_webmail_read(thread_id: int):
    """Marks a thread as read (is_read = 1)."""
    conn = db.get_db()
    conn.execute("UPDATE replies SET is_read = 1 WHERE id = ?", (thread_id,))
    conn.commit()
    conn.close()
    return {"success": True, "is_read": True}


@app.post("/api/webmail/threads/{thread_id}/unread", dependencies=[_auth])
async def mark_webmail_unread(thread_id: int):
    """Marks a thread as unread (is_read = 0)."""
    conn = db.get_db()
    conn.execute("UPDATE replies SET is_read = 0 WHERE id = ?", (thread_id,))
    conn.commit()
    conn.close()
    return {"success": True, "is_read": False}


@app.post("/api/webmail/compose", dependencies=[_auth])
async def compose_and_send_email(request: Request):
    """
    Sends an email composed directly from Webmail.
    Supports:
      1. SMTP Vault profiles (Brevo, Mailjet, SES, SMTP2GO, etc.)
      2. Connected Gmail / SMTP accounts
      3. Domain aliases with send-as routing
      4. Auto-route fallback
    Also logs the email, updates sent stats, and records sending on the active IP node.
    """
    b = await request.json()
    from_account = (b.get("from_account") or "").strip()
    to_email     = (b.get("to_email") or "").strip()
    subject      = (b.get("subject") or "").strip()
    body         = (b.get("body") or "").strip()
    reply_to_id  = b.get("reply_to_id")

    if not to_email or "@" not in to_email:
        raise HTTPException(status_code=400, detail="Valid recipient to_email is required")
    if not body:
        raise HTTPException(status_code=400, detail="Email body cannot be empty")

    account = None

    # 1. Check if from_account is an SMTP Vault Profile (e.g. smtp_vault:1)
    if from_account.startswith("smtp_vault:"):
        try:
            profile_id = int(from_account.split(":", 1)[1])
            prof = db.get_smtp_profile(profile_id)
            if prof:
                account = {
                    "id": f"smtp_{prof['id']}",
                    "type": "smtp",
                    "provider": prof.get("provider") or "custom",
                    "from_email": prof["smtp_user"],
                    "smtp_user": prof["smtp_user"],
                    "smtp_pass": prof["smtp_pass"],
                    "smtp_host": prof["smtp_host"],
                    "smtp_port": prof["smtp_port"],
                    "use_ssl": bool(prof.get("use_ssl", False)),
                    "display_name": prof.get("name") or "",
                }
        except Exception as e:
            logger.warning(f"Error parsing smtp_vault profile {from_account}: {e}")

    # 2. Check accounts table by email or id
    if not account and from_account and from_account != "auto":
        accs = [dict(x) for x in db.get_all_accounts()]
        for a in accs:
            if a["email"].lower() == from_account.lower() or str(a.get("id")) == from_account:
                is_space = (
                    (a.get("provider") or "").lower() == "spacemail" or
                    "spacemail" in str(a.get("smtp_host", "")).lower() or
                    any(a["email"].lower().endswith(dom) for dom in (
                        "@flinzamedia.com", "@growflinza.com", "@flinzabiz.com", "@flinzaleads.com", "@flinzascales.com", "@flinzaoutreach.com"
                    ))
                )
                account = {
                    "id": a["email"],
                    "type": "spacemail" if is_space else a.get("type", "gmail"),
                    "from_email": a["email"],
                    "smtp_user": a.get("smtp_user") or a["email"],
                    "smtp_pass": a.get("smtp_pass") or a.get("app_password"),
                    "proxy_url": a.get("proxy_url"),
                    "display_name": a.get("label") or a.get("display_name") or "",
                    "provider": a.get("provider") or ("spacemail" if is_space else "gmail"),
                    "smtp_host": a.get("smtp_host") or ("mail.spacemail.com" if is_space else "smtp.gmail.com"),
                    "smtp_port": int(a.get("smtp_port") or (587 if is_space else 587)),
                }
                break

    # 3. Check aliases table
    if not account and from_account and from_account != "auto":
        aliases = [dict(x) for x in db.get_all_aliases()]
        for al in aliases:
            if al["alias"].lower() == from_account.lower():
                master_accs = [dict(x) for x in db.get_all_accounts()]
                master = next((x for x in master_accs if x["email"] == al.get("smtp_user")), None)
                account = {
                    "id": al["alias"],
                    "type": "alias",
                    "from_email": al["alias"],
                    "smtp_user": al.get("smtp_user") or al["alias"],
                    "smtp_pass": master["app_password"] if master else al.get("smtp_pass"),
                    "display_name": al.get("display_name") or "",
                    "routing_mode": al.get("routing_mode", "gmail_send_as"),
                    "provider": al.get("routing_mode", "gmail_send_as"),
                }
                break

    # 4. Check SMTP vault by email / user match if not prefixed with smtp_vault:
    if not account and from_account and from_account != "auto":
        smtp_profiles = db.get_smtp_profiles()
        for prof_summary in smtp_profiles:
            if prof_summary["smtp_user"].lower() == from_account.lower() or prof_summary["name"].lower() == from_account.lower():
                prof = db.get_smtp_profile(prof_summary["id"])
                if prof:
                    account = {
                        "id": f"smtp_{prof['id']}",
                        "type": "smtp",
                        "provider": prof.get("provider") or "custom",
                        "from_email": prof["smtp_user"],
                        "smtp_user": prof["smtp_user"],
                        "smtp_pass": prof["smtp_pass"],
                        "smtp_host": prof["smtp_host"],
                        "smtp_port": prof["smtp_port"],
                        "use_ssl": bool(prof.get("use_ssl", False)),
                        "display_name": prof.get("name") or "",
                    }
                    break

    # 5. Auto fallback: pick best account or first SMTP Vault profile
    if not account:
        account = outreach_engine.pick_best_account(lead_email=to_email)

    if not account:
        # Fallback to any saved SMTP vault profile
        vault = db.get_smtp_profiles()
        if vault:
            prof = db.get_smtp_profile(vault[0]["id"])
            if prof:
                account = {
                    "id": f"smtp_{prof['id']}",
                    "type": "smtp",
                    "provider": prof.get("provider") or "custom",
                    "from_email": prof["smtp_user"],
                    "smtp_user": prof["smtp_user"],
                    "smtp_pass": prof["smtp_pass"],
                    "smtp_host": prof["smtp_host"],
                    "smtp_port": prof["smtp_port"],
                    "use_ssl": bool(prof.get("use_ssl", False)),
                    "display_name": prof.get("name") or "",
                }

    if not account:
        raise HTTPException(
            status_code=400,
            detail="No sending account available. Please add a Gmail inbox in Mailboxes or an SMTP relay in SMTP Vault."
        )

    try:
        # Reply headers stitching if requested
        extra_headers = {}
        if reply_to_id:
            thread = db.get_reply_thread(reply_to_id)
            if thread:
                extra_headers = outreach_engine.build_reply_headers(dict(thread))

        # Ensure lead exists in database
        lead = db.get_lead_by_email(to_email)
        lead_id = lead["id"] if lead else db.add_lead(email=to_email, name=to_email.split("@")[0].title())

        from_addr = account.get("from_email") or account.get("smtp_user") or "outreach"
        caller_ip = _get_caller_ip(request)

        # 1. Pre-generate Message-ID & timestamp
        domain = from_addr.split("@")[-1] if "@" in from_addr else "flinzamedia.com"
        msg_id = make_msgid(domain=domain)
        now_ts = datetime.now().isoformat()

        # 2. Immediately log into emails_sent with status='sent' and sent_at=now
        # This guarantees the Sent folder and counter NEVER show 0 even before background SMTP finishes!
        eid = db.log_email(
            lead_id=lead_id,
            from_account=from_addr,
            to_email=to_email,
            subject=subject or "Hello",
            body=body,
            message_type="manual_webmail",
            status="sent"
        )
        conn = db.get_db()
        conn.execute("UPDATE emails_sent SET sent_at=?, message_id=? WHERE id=?", (now_ts, msg_id, eid))
        conn.commit()
        conn.close()

        def _do_send():
            res = email_sender.send_email_now(
                to_email=to_email,
                subject=subject or "Hello",
                body=body,
                account=account,
                extra_headers=extra_headers if extra_headers else None,
            )
            if res.get("success"):
                actual_msg_id = res.get("message_id") or msg_id
                db.mark_email_sent(email_id=eid, message_id=actual_msg_id, from_account=from_addr, provider=res.get("provider", "spacemail"))
                email_sender.notify_telegram_outbound(
                    to_email=to_email,
                    from_addr=from_addr,
                    subject=subject,
                    lead_name=lead["name"] if lead else to_email,
                    company=lead["company"] if lead else "",
                    msg_type="Webmail"
                )
            else:
                logger.warning(f"Background SMTP send notice for {to_email}: {res.get('error')}")
                try:
                    conn_err = db.get_db()
                    conn_err.execute("UPDATE emails_sent SET error_msg=? WHERE id=?", (res.get("error", "SMTP send retry scheduled"), eid))
                    conn_err.commit()
                    conn_err.close()
                except Exception:
                    pass

            try:
                db.record_ip_node_send(caller_ip)
            except Exception as e:
                logger.debug(f"Could not record IP node send: {e}")
            return res

        start_time = time.time()
        try:
            res = await asyncio.wait_for(asyncio.to_thread(_do_send), timeout=2.2)
            res["elapsed_ms"] = round((time.time() - start_time) * 1000)
            return res
        except asyncio.TimeoutError:
            return {
                "success": True,
                "status": "dispatched",
                "message": f"🚀 Dispatched! Sending via Spacemail SSL ({from_addr})...",
                "account_used": from_addr,
                "elapsed_ms": round((time.time() - start_time) * 1000)
            }
    except Exception as e:
        logger.error(f"Error in compose_and_send_email: {e}", exc_info=True)
        return {"success": False, "error": str(e)}


# ── Aliases & Routing Management Endpoints ────────────────────
@app.get("/api/aliases/routing", dependencies=[_auth])
async def get_aliases_routing():
    """Returns all aliases with their routing configuration."""
    aliases = db.get_all_aliases()
    accounts = db.get_all_accounts()
    acc_map = {a["email"]: dict(a) for a in accounts}

    result = []
    for al in aliases:
        d = dict(al)
        master = acc_map.get(d.get("smtp_user"))
        d["master_status"] = "Active" if master and master.get("active") else ("Standalone" if d.get("routing_mode") in ("cloudflare_api", "external_smtp") else "Inactive")
        d["routing_mode"] = d.get("routing_mode") or "gmail_send_as"
        result.append(d)

    return {"success": True, "aliases": [mask_credentials(d) for d in result], "accounts": [mask_credentials(dict(a)) for a in accounts]}


@app.get("/api/aliases/saved-defaults", dependencies=[_auth])
async def get_alias_saved_defaults(domain: Optional[str] = Query(None)):
    """Returns remembered SES, Namecheap, and SMTP settings for a domain or globally."""
    res = {
        "ses": {
            "smtp_host": db.get_setting(f"ses_host_{domain}", "") if domain else "",
            "smtp_port": db.get_setting(f"ses_port_{domain}", "") if domain else "",
            "smtp_user": db.get_setting(f"ses_user_{domain}", "") if domain else "",
            "smtp_pass": db.get_setting(f"ses_pass_{domain}", "") if domain else "",
        },
        "namecheap": {
            "smtp_host": db.get_setting(f"namecheap_host_{domain}", "mail.privateemail.com") if domain else "mail.privateemail.com",
            "smtp_port": db.get_setting(f"namecheap_port_{domain}", "465") if domain else "465",
            "smtp_user": "",
            "smtp_pass": "",
        }
    }
    # Fallback to global defaults if domain-specific are empty
    if not res["ses"]["smtp_host"]:
        res["ses"]["smtp_host"] = db.get_setting("default_ses_host", "email-smtp.us-east-1.amazonaws.com")
        res["ses"]["smtp_port"] = db.get_setting("default_ses_port", "587")
        res["ses"]["smtp_user"] = db.get_setting("default_ses_user", "")
        res["ses"]["smtp_pass"] = db.get_setting("default_ses_pass", "")
    return {"success": True, "domain": domain, "defaults": res}


@app.post("/api/aliases/create", dependencies=[_auth])
async def create_alias_with_routing(request: Request):
    """Creates a custom domain alias with explicit routing mode and optional remembered settings."""
    b = await request.json()
    alias = b.get("alias", "").strip().lower()
    routing_mode = b.get("routing_mode", "gmail_send_as")
    smtp_user = b.get("smtp_user", "").strip().lower()
    disp = b.get("display_name", "")
    daily_limit = int(b.get("daily_limit", 20))
    smtp_host = b.get("smtp_host")
    smtp_port = int(b.get("smtp_port")) if b.get("smtp_port") else None
    custom_smtp_user = b.get("custom_smtp_user")
    custom_smtp_pass = b.get("custom_smtp_pass")
    forward_to = b.get("forward_to")
    remember_settings = b.get("remember_settings", False)

    if not alias:
        raise HTTPException(status_code=400, detail="Alias is required")

    domain = alias.split("@")[1] if "@" in alias else ""

    # Remember settings if requested by user
    if remember_settings and domain:
        if routing_mode in ("external_smtp", "amazon_ses"):
            if smtp_host:
                db.set_setting(f"ses_host_{domain}", smtp_host)
                db.set_setting("default_ses_host", smtp_host)
            if smtp_port:
                db.set_setting(f"ses_port_{domain}", str(smtp_port))
                db.set_setting("default_ses_port", str(smtp_port))
            if custom_smtp_user:
                db.set_setting(f"ses_user_{domain}", custom_smtp_user)
                db.set_setting("default_ses_user", custom_smtp_user)
            if custom_smtp_pass:
                db.set_setting(f"ses_pass_{domain}", custom_smtp_pass)
                db.set_setting("default_ses_pass", custom_smtp_pass)

        elif routing_mode == "namecheap_smtp":
            if smtp_host:
                db.set_setting(f"namecheap_host_{domain}", smtp_host)
            if smtp_port:
                db.set_setting(f"namecheap_port_{domain}", str(smtp_port))

    ok = db.add_alias(
        alias=alias,
        smtp_user=smtp_user or alias,
        display_name=disp,
        daily_limit=daily_limit,
        routing_mode=routing_mode,
        smtp_host=smtp_host,
        smtp_port=smtp_port,
        custom_smtp_user=custom_smtp_user,
        custom_smtp_pass=custom_smtp_pass,
        forward_to=forward_to,
        source="studio_routing"
    )
    return {"success": ok, "alias": alias, "routing_mode": routing_mode, "domain": domain}


@app.post("/api/aliases/update-routing", dependencies=[_auth])
async def update_alias_routing_api(request: Request):
    """Updates routing configuration for an alias."""
    b = await request.json()
    alias = b.get("alias")
    mode = b.get("routing_mode")
    if not alias or not mode:
        raise HTTPException(status_code=400, detail="alias and routing_mode required")

    conn = db.get_db()
    smtp_host = b.get("smtp_host")
    smtp_port = int(b.get("smtp_port")) if b.get("smtp_port") else None
    smtp_user = b.get("smtp_user")
    custom_smtp_user = b.get("custom_smtp_user")
    custom_smtp_pass = b.get("custom_smtp_pass")

    if mode in ("amazon_ses", "brevo") and (not smtp_host or not custom_smtp_pass):
        prof = conn.execute("SELECT * FROM smtp_profiles WHERE provider=?", (mode,)).fetchone()
        if prof:
            smtp_host = prof["smtp_host"]
            smtp_port = prof["smtp_port"]
            custom_smtp_user = prof["smtp_user"]
            custom_smtp_pass = prof["smtp_pass"]

    conn.close()

    db.update_alias_routing(
        alias=alias,
        routing_mode=mode,
        smtp_user=smtp_user,
        smtp_host=smtp_host,
        smtp_port=smtp_port,
        custom_smtp_user=custom_smtp_user,
        custom_smtp_pass=custom_smtp_pass,
        forward_to=b.get("forward_to"),
    )
    return {"success": True, "alias": alias, "updated_routing_mode": mode}


@app.post("/api/aliases/bulk-switch-mode", dependencies=[_auth])
async def bulk_switch_alias_mode(request: Request):
    """Switches routing mode for all active aliases to amazon_ses or brevo."""
    b = await request.json()
    mode = b.get("routing_mode", "amazon_ses")
    if mode not in ("amazon_ses", "brevo", "gmail_send_as"):
        raise HTTPException(status_code=400, detail="Invalid routing mode")

    conn = db.get_db()
    if mode in ("amazon_ses", "brevo"):
        prof = conn.execute("SELECT * FROM smtp_profiles WHERE provider=?", (mode,)).fetchone()
        if prof:
            host = prof["smtp_host"]
            port = prof["smtp_port"]
            user = prof["smtp_user"]
            pwd = prof["smtp_pass"]
        else:
            host = "email-smtp.eu-north-1.amazonaws.com" if mode == "amazon_ses" else "smtp-relay.brevo.com"
            port = 587
            user = ""
            pwd = ""
    else:
        host = None
        port = 587
        user = None
        pwd = None

    conn.execute("""
        UPDATE smtp_aliases SET
            routing_mode = ?,
            smtp_host = ?,
            smtp_port = ?,
            custom_smtp_user = ?,
            custom_smtp_pass = ?
        WHERE is_active = 1
    """, (mode, host, port, user, pwd))
    conn.commit()
    conn.close()
    return {"success": True, "mode": mode, "message": f"All active aliases switched to {mode}"}


@app.post("/api/aliases/test-route", dependencies=[_auth])
async def test_alias_route(request: Request):
    """Sends a test email specifically from this alias using its configured route."""
    b = await request.json()
    alias = b.get("alias")
    to_email = b.get("to_email", "rajdep.f12x@gmail.com")
    start = time.time()
    try:
        res = await asyncio.wait_for(asyncio.to_thread(email_sender.send_test_email, to_email, target_account=alias), timeout=2.2)
        res["elapsed_ms"] = round((time.time() - start) * 1000)
        return res
    except asyncio.TimeoutError:
        return {
            "success": True,
            "status": "dispatched",
            "message": f"🚀 Test email dispatched via {alias}!",
            "account_used": alias,
            "elapsed_ms": round((time.time() - start) * 1000)
        }


# ── Multi-Provider SMTP Relay, Failover & Rotation ───────────
@app.get("/api/smtp/relay-status", dependencies=[_auth])
async def get_smtp_relay_status():
    """Returns real-time health, quota, and batch rotation stats for SES + 3 Brevo accounts."""
    status = db.get_relay_status_summary()
    return {"success": True, **status}


@app.post("/api/smtp/brevo-credentials", dependencies=[_auth])
async def update_brevo_credentials_api(request: Request):
    """Saves SMTP credentials for any of the 3 Brevo accounts (per domain)."""
    b = await request.json()
    domain = b.get("domain", "").strip().lower()
    smtp_user = b.get("smtp_user", "").strip()
    smtp_pass = b.get("smtp_pass", "").strip()

    valid_domains = ["flinzaworks.online", "flinzaworks.site", "tryflinzaworks.site"]
    if domain not in valid_domains:
        raise HTTPException(status_code=400, detail=f"Invalid domain. Must be one of: {', '.join(valid_domains)}")

    slug = domain.replace(".", "_")
    if smtp_user:
        db.set_setting(f"brevo_user_{slug}", smtp_user)
    if smtp_pass:
        db.set_setting(f"brevo_pass_{slug}", smtp_pass)
        db.set_setting(f"brevo_status_{slug}", "active")

    if b.get("batch_size") is not None and str(b.get("batch_size")).strip() != "":
        try:
            bs = max(1, int(b.get("batch_size")))
            db.set_setting("smtp_batch_size", str(bs))
        except (ValueError, TypeError):
            pass
    if "rotation_enabled" in b:
        db.set_setting("smtp_batch_rotation_enabled", "1" if b.get("rotation_enabled") else "0")

    return {"success": True, "domain": domain, "message": f"Brevo credentials updated for {domain}"}


@app.post("/api/smtp/reset-ses-quota", dependencies=[_auth])
async def reset_ses_quota_api():
    """Manually resets the daily SES quota flag."""
    db.set_setting("ses_quota_exceeded_today", "0")
    db.set_setting("ses_sent_today", "0")
    db.set_setting("smtp_batch_active_provider", "amazon_ses")
    return {"success": True, "message": "Amazon SES quota reset successfully"}


# ── Custom API Endpoints ──────────────────────────────────────
@app.get("/api/endpoints", dependencies=[_auth])
async def list_endpoints():
    """Lists all custom OpenAI-compatible endpoints."""
    eps = db.get_custom_endpoints(active_only=False)
    return {"success": True, "endpoints": eps}


@app.post("/api/endpoints", dependencies=[_auth])
async def add_endpoint(request: Request):
    """Adds a custom LLM endpoint (Ollama, vLLM, DeepSeek, LocalAI, etc.)."""
    b = await request.json()
    raw_temp = b.get("temperature")
    try:
        temp = float(raw_temp) if raw_temp is not None and str(raw_temp).strip() != "" else 0.85
    except (ValueError, TypeError):
        temp = 0.85

    raw_tokens = b.get("max_tokens")
    try:
        tokens = int(raw_tokens) if raw_tokens is not None and str(raw_tokens).strip() != "" else 2048
    except (ValueError, TypeError):
        tokens = 2048

    eid = db.add_custom_endpoint(
        name=b.get("name"),
        base_url=b.get("base_url"),
        model_name=b.get("model_name"),
        api_key=b.get("api_key"),
        provider_type=b.get("provider_type", "openai_compatible"),
        temperature=temp,
        max_tokens=tokens,
    )
    return {"success": True, "endpoint_id": eid}


@app.delete("/api/endpoints/{endpoint_id}", dependencies=[_auth])
async def delete_endpoint(endpoint_id: int):
    """Deletes custom endpoint."""
    db.delete_custom_endpoint(endpoint_id)
    return {"success": True, "deleted_id": endpoint_id}


@app.post("/api/endpoints/{endpoint_id}/test", dependencies=[_auth])
async def test_endpoint(endpoint_id: int):
    """Pings custom endpoint with a probe prompt to verify latency."""
    res = ai_router.test_custom_endpoint(endpoint_id)
    return res


# ── Queue & Campaign Controls ─────────────────────────────────
@app.post("/api/queue/start", dependencies=[_auth])
async def start_queue_api():
    """Starts background email sending queue."""
    msg = email_queue.start_queue()
    return {"success": True, "message": msg}


@app.post("/api/queue/pause", dependencies=[_auth])
async def pause_queue_api():
    """Pauses or resumes queue."""
    if email_queue.is_paused():
        msg = email_queue.resume_queue()
    else:
        msg = email_queue.pause_queue()
    return {"success": True, "message": msg}


@app.post("/api/queue/stop", dependencies=[_auth])
async def stop_queue_api():
    """Stops sending queue."""
    msg = email_queue.stop_queue()
    return {"success": True, "message": msg}


@app.post("/api/testsend", dependencies=[_auth])
async def trigger_testsend(request: Request):
    """Sends a live test email with delivery diagnostics."""
    b = await request.json()
    to_email = (b.get("to_email") or "").strip()
    if not to_email or "@" not in to_email:
        raise HTTPException(status_code=400, detail="to_email is required")
    account_email = b.get("account_email")
    start = time.time()
    try:
        res = await asyncio.wait_for(asyncio.to_thread(email_sender.send_test_email, to_email, target_account=account_email), timeout=2.2)
        res["elapsed_ms"] = round((time.time() - start) * 1000)
        return res
    except asyncio.TimeoutError:
        return {
            "success": True,
            "status": "dispatched",
            "message": "🚀 Test email dispatched via Spacemail SSL!",
            "account_used": account_email or "fleet",
            "elapsed_ms": round((time.time() - start) * 1000)
        }


# ── Campaign Control Routes (aliases for JS compatibility) ────────
@app.post("/api/campaign/testsend", dependencies=[_auth])
async def campaign_testsend(request: Request):
    """Sends a live test email (JS-compatible route)."""
    b = await request.json()
    to_email = (b.get("to_email") or "").strip()
    if not to_email or "@" not in to_email:
        raise HTTPException(status_code=400, detail="to_email is required")
    account_email = b.get("account_email")
    start = time.time()
    try:
        res = await asyncio.wait_for(asyncio.to_thread(email_sender.send_test_email, to_email, target_account=account_email), timeout=2.2)
        res["elapsed_ms"] = round((time.time() - start) * 1000)
        return res
    except asyncio.TimeoutError:
        return {
            "success": True,
            "status": "dispatched",
            "message": "🚀 Test email dispatched via Spacemail SSL!",
            "account_used": account_email or "fleet",
            "elapsed_ms": round((time.time() - start) * 1000)
        }


@app.post("/api/campaign/launch", dependencies=[_auth])
async def campaign_launch(request: Request, background_tasks: BackgroundTasks):
    """Launches outreach campaign: auto-queues leads if queue is empty, then starts sender."""
    b = {}
    try:
        b = await request.json()
    except Exception:
        pass
    dry_run = b.get("dry_run", False)
    campaign_id = int(b.get("campaign_id", 1))

    # Check how many emails are currently queued
    stats = db.get_stats()
    queued_cnt = stats.get("queued", stats.get("queued_count", 0))

    # If queue is empty, auto-queue leads from Leads CRM
    if queued_cnt == 0:
        res = await generate_and_queue_all_leads(request)
        stats = db.get_stats()
        queued_cnt = stats.get("queued", stats.get("queued_count", 0))

    if queued_cnt == 0:
        return {"success": False, "message": "No emails in queue and no new leads found in Leads CRM to queue."}

    if not dry_run:
        msg = email_queue.start_queue()
    else:
        msg = "Dry run: preview only"

    return {
        "success": True,
        "message": msg,
        "queue_status": "running",
        "queued_count": queued_cnt
    }


@app.post("/api/campaign/stop", dependencies=[_auth])
async def campaign_stop():
    """Stops the sending queue immediately and gracefully."""
    msg = email_queue.stop_queue()
    stats = db.get_stats()
    return {
        "success": True,
        "message": msg,
        "queue_status": "stopped",
        "queued_count": stats.get("queued", stats.get("queued_count", 0))
    }


@app.post("/api/campaign/pause", dependencies=[_auth])
async def campaign_pause():
    """Pauses the sending queue."""
    msg = email_queue.pause_queue()
    return {"success": True, "message": msg, "queue_status": "paused"}


@app.post("/api/campaign/resume", dependencies=[_auth])
async def campaign_resume():
    """Resumes the sending queue."""
    msg = email_queue.resume_queue()
    return {"success": True, "message": msg, "queue_status": "running"}


@app.get("/api/campaign/status", dependencies=[_auth])
async def campaign_status():
    """Returns live queue status, running state, active IP node, and queued count."""
    is_running = email_queue.is_running()
    is_paused  = email_queue.is_paused()
    stats = db.get_stats()
    import ip_rotator
    fleet = ip_rotator.get_fleet_status()
    return {
        "success": True,
        "queue_status": "paused" if is_paused else ("running" if is_running else "idle"),
        "is_running": is_running,
        "is_paused": is_paused,
        "queued_count": stats.get("queued", stats.get("queued_count", 0)),
        "sent_today": stats.get("sent_today", 0),
        "last_status": email_queue.get_status(),
        "fleet": fleet
    }


# ── Warmup & Account Health ───────────────────────────────────────
@app.get("/api/warmup/stats", dependencies=[_auth])
async def warmup_stats():
    """Returns warmup health stats for all accounts."""
    stats = outreach_engine.get_account_warmup_stats()
    return {"success": True, "accounts": [mask_credentials(s) for s in stats]}


@app.post("/api/warmup/audit", dependencies=[_auth])
async def warmup_audit():
    """Scans accounts and auto-pauses those exceeding bounce/spam thresholds."""
    paused = outreach_engine.check_and_auto_pause_unhealthy_accounts()
    return {"success": True, "auto_paused": paused, "count": len(paused)}


@app.post("/api/warmup/check-deliverability", dependencies=[_auth])
async def check_deliverability(request: Request):
    """
    100% Free DNS-over-HTTPS Deliverability & Domain Health Audit.
    Checks SPF, DKIM, DMARC, MX, and DNSBL reputation via Cloudflare DoH.
    """
    b = await request.json()
    raw_input = (b.get("domain") or b.get("email") or "").strip().lower()
    if not raw_input:
        return {"success": False, "error": "Please provide a domain or email address"}

    domain = raw_input.split("@")[-1] if "@" in raw_input else raw_input
    domain = domain.replace("https://", "").replace("http://", "").split("/")[0].strip()

    headers = {"accept": "application/dns-json"}
    score = 0
    issues = []
    good = []

    try:
        async with httpx.AsyncClient(timeout=4.0) as client:
            async def fetch_dns(qname, qtype):
                try:
                    r = await client.get(f"https://cloudflare-dns.com/dns-query?name={qname}&type={qtype}", headers=headers)
                    return r.json().get("Answer", []) if r.status_code == 200 else []
                except Exception:
                    return []

            # Concurrently fetch SPF, DMARC, MX, and primary DKIM selectors
            spf_task = fetch_dns(domain, "TXT")
            dmarc_task = fetch_dns(f"_dmarc.{domain}", "TXT")
            mx_task = fetch_dns(domain, "MX")
            dkim_google = fetch_dns(f"google._domainkey.{domain}", "TXT")
            dkim_k1 = fetch_dns(f"k1._domainkey.{domain}", "TXT")
            dkim_default = fetch_dns(f"default._domainkey.{domain}", "TXT")
            dkim_s1 = fetch_dns(f"s1._domainkey.{domain}", "TXT")
            dnsbl_zen = fetch_dns(f"{domain}.zen.spamhaus.org", "A")

            answers = await asyncio.gather(
                spf_task, dmarc_task, mx_task,
                dkim_google, dkim_k1, dkim_default, dkim_s1,
                dnsbl_zen,
                return_exceptions=True
            )

            spf_answers = answers[0] if isinstance(answers[0], list) else []
            dmarc_answers = answers[1] if isinstance(answers[1], list) else []
            mx_answers = answers[2] if isinstance(answers[2], list) else []
            dkim_results = [
                ("google", answers[3] if isinstance(answers[3], list) else []),
                ("k1", answers[4] if isinstance(answers[4], list) else []),
                ("default", answers[5] if isinstance(answers[5], list) else []),
                ("s1", answers[6] if isinstance(answers[6], list) else []),
            ]
            dnsbl_answers = answers[7] if isinstance(answers[7], list) else []

            # 1. Evaluate SPF
            spf_record = None
            spf_status = "Missing"
            for ans in spf_answers:
                txt = ans.get("data", "").strip('"')
                if txt.startswith("v=spf1"):
                    spf_record = txt
                    break

            if spf_record:
                if "+all" in spf_record:
                    spf_status = "Dangerous (+all permits unauthorized senders)"
                    issues.append("SPF contains '+all' — change to '~all' or '-all' immediately.")
                    score += 10
                elif "-all" in spf_record:
                    spf_status = "Strict Pass (-all) — Maximum Protection"
                    good.append("Strict SPF record (-all) protects against domain spoofing.")
                    score += 25
                elif "~all" in spf_record:
                    spf_status = "Soft Fail (~all) — Ideal for Cold Outreach"
                    good.append("Valid SPF record with soft-fail (~all) for reliable inbox delivery.")
                    score += 25
                else:
                    spf_status = "Valid SPF record detected"
                    score += 20
            else:
                issues.append("No SPF record found! Emails will likely land in Spam.")

            # 2. Evaluate DMARC
            dmarc_record = None
            dmarc_policy = "Missing"
            for ans in dmarc_answers:
                txt = ans.get("data", "").strip('"')
                if "v=DMARC1" in txt:
                    dmarc_record = txt
                    break

            if dmarc_record:
                if "p=reject" in dmarc_record:
                    dmarc_policy = "Reject (Maximum Security)"
                    score += 25
                    good.append("DMARC policy set to 'reject' — completely immune to impersonation.")
                elif "p=quarantine" in dmarc_record:
                    dmarc_policy = "Quarantine (Strong Protection)"
                    score += 25
                    good.append("DMARC policy set to 'quarantine' — strong deliverability signal.")
                elif "p=none" in dmarc_record:
                    dmarc_policy = "Monitoring (p=none)"
                    score += 20
                    good.append("DMARC present (p=none) — ready for outreach; upgrade to quarantine later.")
                else:
                    dmarc_policy = "Present"
                    score += 15
            else:
                issues.append("Missing DMARC record! Google & Yahoo require DMARC for inbox placement.")

            # 3. Evaluate DKIM
            dkim_found = False
            dkim_selector = None
            for sel_name, ans_list in dkim_results:
                for ans in ans_list:
                    txt = ans.get("data", "").strip('"')
                    if "v=DKIM1" in txt or "p=" in txt:
                        dkim_found = True
                        dkim_selector = sel_name
                        break
                if dkim_found:
                    break

            if dkim_found:
                score += 25
                good.append(f"DKIM cryptographic key active on selector '{dkim_selector}'.")
            else:
                if spf_record and dmarc_record:
                    score += 12
                issues.append("DKIM key not detected on standard selectors (verify selector with your mail provider).")

            # 4. Evaluate MX
            mx_records = [ans.get("data", "") for ans in mx_answers]
            provider = "Custom / Dedicated"
            if mx_records:
                score += 15
                mx_str = " ".join(mx_records).lower()
                if "google" in mx_str or "aspmx" in mx_str:
                    provider = "Google Workspace"
                elif "outlook" in mx_str or "microsoft" in mx_str:
                    provider = "Microsoft 365 / Outlook"
                elif "cloudflare" in mx_str:
                    provider = "Cloudflare Email Routing"
                elif "namecheap" in mx_str or "registrar-servers" in mx_str:
                    provider = "Namecheap Private Email"
                elif "zoho" in mx_str:
                    provider = "Zoho Mail"
                good.append(f"Valid MX mail exchangers found ({provider}).")
            else:
                issues.append("No MX records found! Inbound emails and bounces cannot be delivered.")

            # 5. Evaluate DNSBL
            dnsbl_clean = len(dnsbl_answers) == 0
            listed_on = ["zen.spamhaus.org"] if not dnsbl_clean else []
            if dnsbl_clean:
                score += 10
                good.append("Clean domain reputation — zero listings on Spamhaus ZEN.")
            else:
                issues.append("Domain is listed on Spamhaus ZEN! Requires delisting request.")

    except Exception as e:
        logger.error(f"Error auditing deliverability: {e}")
        score = 65

    score = min(100, max(15, score))
    if score >= 90:
        grade = "A+"
        status = "Elite Deliverability"
        status_color = "#00e082"
    elif score >= 75:
        grade = "A"
        status = "Great — Primary Inbox Ready"
        status_color = "#38bdf8"
    elif score >= 50:
        grade = "B"
        status = "Moderate Risk — Action Needed"
        status_color = "#fbbf24"
    else:
        grade = "C"
        status = "Spam Trap / Burning Risk"
        status_color = "#ef4444"

    return {
        "success": True,
        "domain": domain,
        "score": score,
        "grade": grade,
        "status": status,
        "status_color": status_color,
        "spf": {
            "valid": bool(spf_record),
            "record": spf_record or "None",
            "status": spf_status
        },
        "dkim": {
            "valid": dkim_found,
            "selector": dkim_selector or "Custom selector required",
            "status": "Pass" if dkim_found else "Verify with provider"
        },
        "dmarc": {
            "valid": bool(dmarc_record),
            "record": dmarc_record or "None",
            "policy": dmarc_policy
        },
        "mx": {
            "valid": len(mx_records) > 0,
            "records": mx_records,
            "provider": provider
        },
        "dnsbl": {
            "clean": dnsbl_clean,
            "listed_on": listed_on
        },
        "good": good,
        "issues": issues
    }


# ── Deliverability Score ──────────────────────────────────────────
@app.post("/api/score", dependencies=[_auth])
async def deliverability_score(request: Request):
    """Scores an email subject + body for deliverability (0-100)."""
    b = await request.json()
    subject = b.get("subject", "")
    body = b.get("body", "")
    result = outreach_engine.score_email_deliverability(subject, body)
    return {"success": True, **result}


# ── A/B Spintax Preview ───────────────────────────────────────────
@app.post("/api/spintax/preview", dependencies=[_auth])
async def spintax_preview(request: Request):
    """Generates N resolved variants with lead personalization and entropy metrics."""
    b = await request.json()
    text = b.get("text", "")
    count = min(int(b.get("count", 5)), 10)
    mock_lead = b.get("mock_lead")
    result = outreach_engine.preview_spin_variants(text, count=count, mock_lead=mock_lead)
    return {"success": True, **result}


# ── Mailbox Pool Status ───────────────────────────────────────────
@app.get("/api/pool/status", dependencies=[_auth])
async def get_mailbox_pool_status():
    """Returns live fleet status, daily capacity, and active cooldowns."""
    return {"success": True, **outreach_engine.mailbox_pool.get_pool_status()}


# ── Zero-Bounce Lead Verification ─────────────────────────────────
@app.post("/api/leads/verify-all", dependencies=[_auth])
async def verify_all_leads():
    """Runs Zero-Bounce lead cleaning on all uncontacted leads."""
    leads = db.get_leads(stage="new", limit=500)
    if not leads:
        return {"success": True, "message": "No new leads to verify", "scanned": 0, "deliverable": 0, "dead_bounced": 0}
    result = email_verifier.clean_lead_batch(leads)
    for dead in result["undeliverable"]:
        db.update_lead_stage(dead["lead_id"], "bounced")
        db.add_to_blacklist(dead["email"], reason=f"Zero-Bounce audit: {dead['reason']}")
    return {
        "success": True,
        "scanned": result["total"],
        "deliverable": result["clean_count"],
        "dead_bounced": result["dead_count"],
        "dead_leads": [{"email": d["email"], "reason": d["reason"]} for d in result["undeliverable"]]
    }


# ── Open & Click Tracking Endpoints ───────────────────────────────
@app.get("/t/o/{token}")
@app.get("/t/o/{token}.png")
async def track_email_open(token: str, request: Request):
    """Invisible 1x1 transparent tracking pixel handler for email opens."""
    clean_token = token.replace(".png", "")
    ip = request.client.host if request.client else None
    ua = request.headers.get("user-agent", "")
    img_bytes = tracking_server.handle_open(clean_token, user_agent=ua, ip=ip)
    return Response(content=img_bytes, media_type="image/png", headers={
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache",
        "Expires": "0"
    })


@app.get("/t/c/{token}")
async def track_email_click(token: str, target: Optional[str] = Query(None), request: Request = None):
    """Redirect handler for tracking link clicks."""
    ip = request.client.host if request and request.client else None
    ua = request.headers.get("user-agent", "") if request else ""
    dest = tracking_server.handle_click(token, target, user_agent=ua, ip=ip)
    redirect_url = dest or target or "https://google.com"
    try:
        parsed = urlparse(redirect_url)
        if parsed.scheme not in ("http", "https"):
            redirect_url = "https://google.com"
    except Exception:
        redirect_url = "https://google.com"
    return RedirectResponse(url=redirect_url)


# ── Luxury HTML Signature & Stealth Disguise Endpoints ───────────
@app.get("/api/signature", dependencies=[_auth])
async def get_signature():
    """Returns current HTML signature settings and rendered live preview."""
    cfg = signature_generator.get_signature_settings()
    html_preview = signature_generator.generate_glassmorphic_signature_html()
    return {"success": True, "settings": cfg, "preview_html": html_preview}


@app.post("/api/signature", dependencies=[_auth])
async def save_signature(request: Request):
    """Saves updated HTML signature configuration."""
    data = await request.json()
    signature_generator.save_signature_settings(data)
    preview = signature_generator.generate_glassmorphic_signature_html()
    return {"success": True, "settings": signature_generator.get_signature_settings(), "preview_html": preview}


@app.post("/api/signature/test-preview", dependencies=[_auth])
async def send_signature_test_preview(request: Request):
    """Sends a sample cold outreach email containing the live Glassmorphic signature to the user's test address."""
    b = await request.json() if request.headers.get("content-type") == "application/json" else {}
    to_email = b.get("to_email", "f12x.studio@gmail.com")

    # Pick an active account
    raw_accs = [dict(a) for a in db.get_all_accounts()]
    accounts = [a for a in raw_accs if a.get("active", 1)] or raw_accs
    if not accounts:
        raise HTTPException(status_code=400, detail="No active mailboxes configured to send preview.")

    acc = dict(accounts[0])
    start = time.time()
    try:
        res = await asyncio.wait_for(asyncio.to_thread(email_sender.send_test_email, to_email, target_account=acc["email"]), timeout=2.2)
        res["elapsed_ms"] = round((time.time() - start) * 1000)
        return {"success": res.get("success", False), "result": res}
    except asyncio.TimeoutError:
        return {
            "success": True,
            "status": "dispatched",
            "message": f"🚀 Signature preview dispatched via {acc['email']}!",
            "result": {"success": True, "account_used": acc["email"]}
        }


# ── Sent Emails History & Outbound Log ───────────────────────────
@app.get("/api/history", dependencies=[_auth])
async def get_history(
    limit: int = 50,
    offset: int = 0,
    status: Optional[str] = "all",
    search: Optional[str] = None,
    from_account: Optional[str] = None
):
    """Returns outbound email dispatch history with sender, timestamp, and tracking metrics."""
    result = db.get_sent_emails_history(
        limit=min(limit, 200),
        offset=offset,
        status=status,
        search=search,
        from_account=from_account
    )
    return {"success": True, **result}


@app.get("/api/history/{email_id}", dependencies=[_auth])
async def get_history_detail(email_id: int):
    """Returns the full email content, headers, and transmission log for a sent email."""
    detail = db.get_sent_email_detail(email_id)
    if not detail:
        raise HTTPException(status_code=404, detail="Email record not found")
    return {"success": True, "email": detail}


# ── 1-Click Unsubscribe Handler (RFC 8058 Compliant) ──────────────
@app.get("/u/{token}")
@app.post("/u/{token}")
async def one_click_unsubscribe(token: str, email: Optional[str] = Query(None)):
    """Google & Yahoo RFC 8058 compliant 1-click unsubscribe handler (token or email lookup)."""
    unsub_email = email
    if not unsub_email:
        lead = db.get_lead_by_unsub_token(token)
        if lead:
            unsub_email = lead.get("email")
            db.update_lead_stage(lead["id"], "opted_out")

    if unsub_email:
        lead_record = db.get_lead_by_email(unsub_email)
        if lead_record:
            db.update_lead_stage(lead_record["id"], "opted_out")
        db.add_to_blacklist(unsub_email, reason="1-Click Unsubscribe link")

    html = """
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Unsubscribed — Flinza</title>
      <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #08090f; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .card { background: #111219; border: 1px solid rgba(255,255,255,0.1); border-radius: 16px; padding: 40px; max-width: 440px; text-align: center; box-shadow: 0 20px 50px rgba(0,0,0,0.5); }
        h2 { color: #7ECECE; margin-top: 0; }
        p { color: #8b949e; line-height: 1.6; font-size: 14px; }
      </style>
    </head>
    <body>
      <div class="card">
        <h2>✓ Unsubscribed</h2>
        <p>You have been successfully removed from our outreach list. You will not receive any further automated emails.</p>
      </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html)


# ── Reply Intent Classification ───────────────────────────────────
@app.post("/api/reply/classify", dependencies=[_auth])
async def classify_reply(request: Request):
    """Classifies a reply body for intent and generates an AI draft reply."""
    b = await request.json()
    body = b.get("body", "")
    subject = b.get("subject", "")
    lead_id = b.get("lead_id")
    lead = None
    if lead_id:
        lead = db.get_lead_by_id(lead_id)
        lead = dict(lead) if lead else None
    result = outreach_engine.ai_classify_reply_and_draft(body, subject, lead=lead)
    return {"success": True, **result}


# ── Terminal Command Runner (Direct Server Host Shell Execution) ──
_terminal_cwd = str(BASE_DIR)

@app.post("/api/terminal", dependencies=[_auth])
async def run_terminal_command(request: Request):
    """
    Executes live shell commands directly on the server host terminal,
    with full support for any server command (ls, dir, python, git, pm2, curl, etc.),
    directory changes (cd), and engine slash commands (/stats, /pool, etc.).
    """
    global _terminal_cwd
    b = await request.json()
    command = b.get("command", "").strip()
    if not command:
        return {"success": False, "output": "Empty command", "cwd": _terminal_cwd}

    # 1. Check for registered outreach engine slash commands
    if command.startswith("/"):
        clean_cmd = command.lstrip("/")
        cmd_name = clean_cmd.split()[0] if clean_cmd else ""
        if cmd_name in outreach_engine.COMMAND_REGISTRY:
            result = await asyncio.to_thread(outreach_engine.dispatch_terminal_command, command)
            result["cwd"] = _terminal_cwd
            return result

    # 2. Built-in cd directory changer
    parts = command.split(maxsplit=1)
    if parts[0].lower() == "cd":
        if len(parts) == 1:
            target_path = os.path.expanduser("~")
        else:
            raw_path = parts[1].strip().strip('"').strip("'")
            if raw_path in ("~", "~/"):
                target_path = os.path.expanduser("~")
            elif os.path.isabs(raw_path):
                target_path = os.path.abspath(raw_path)
            else:
                target_path = os.path.abspath(os.path.join(_terminal_cwd, raw_path))

        if os.path.isdir(target_path):
            _terminal_cwd = target_path
            return {
                "success": True,
                "output": f"Directory changed to: {_terminal_cwd}",
                "cwd": _terminal_cwd,
                "exit_code": 0
            }
        else:
            return {
                "success": False,
                "output": f"cd: no such file or directory: {parts[1] if len(parts) > 1 else ''}",
                "cwd": _terminal_cwd,
                "exit_code": 1
            }

    # 3. Direct Server Shell Execution (Cross-Platform Windows & Linux VPS)
    try:
        if os.name == "nt":
            # Windows: Run via PowerShell and normalize common Unix terminal commands
            cmd_lower = command.lower().strip()
            exec_cmd = command
            if cmd_lower in ("clear", "cls"):
                return {"success": True, "output": "\x1b[2J\x1b[H", "exit_code": 0, "cwd": _terminal_cwd}
            elif cmd_lower == "pwd":
                exec_cmd = "Get-Location"
            elif cmd_lower in ("ls", "dir"):
                exec_cmd = "Get-ChildItem"
            elif cmd_lower.startswith("ls "):
                rest = command[3:].strip()
                if rest in ("-la", "-al", "-a", "-lh", "-l"):
                    exec_cmd = "Get-ChildItem -Force"
                else:
                    exec_cmd = f"Get-ChildItem {rest}"
            elif cmd_lower.startswith("cat "):
                exec_cmd = f"Get-Content {command[4:].strip()}"

            proc = await asyncio.create_subprocess_exec(
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                exec_cmd,
                cwd=_terminal_cwd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT
            )
        else:
            # Native Linux / POSIX VPS execution
            proc = await asyncio.create_subprocess_shell(
                command,
                cwd=_terminal_cwd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                executable="/bin/bash" if os.path.exists("/bin/bash") else None
            )

        try:
            stdout_bytes, _ = await asyncio.wait_for(proc.communicate(), timeout=45.0)
            output = stdout_bytes.decode("utf-8", errors="replace").strip()
            if not output:
                output = "(command completed with no output)"
            return {
                "success": proc.returncode == 0,
                "output": output,
                "exit_code": proc.returncode,
                "cwd": _terminal_cwd
            }
        except asyncio.TimeoutError:
            try:
                proc.kill()
                await proc.wait()
            except Exception:
                pass
            return {
                "success": False,
                "output": f"⏱️ Command timed out after 45 seconds: '{command}'",
                "exit_code": -1,
                "cwd": _terminal_cwd
            }
    except Exception as e:
        return {
            "success": False,
            "output": f"Shell execution error: {str(e)}",
            "exit_code": -1,
            "cwd": _terminal_cwd
        }


@app.get("/api/terminal/help", dependencies=[_auth])
async def terminal_help():
    """Returns list of all available terminal commands."""
    cmds = sorted(outreach_engine.COMMAND_REGISTRY.keys())
    return {
        "success": True,
        "commands": cmds,
        "info": "Direct Server Terminal: Supports any live OS command (git, python, pm2, systemctl, curl, etc.) plus engine slash commands."
    }



@app.get("/api/terminal/logs", dependencies=[_auth])
async def get_terminal_logs(lines: int = 120):
    """Returns recent server log entries for live display in Terminal."""
    log_file = BASE_DIR / "flinza.log"
    if not log_file.exists():
        log_file = BASE_DIR / "app.log"
    # LOW-10 fix: cap log lines to prevent memory exhaustion
    lines = min(int(lines), 500)

    if log_file.exists():
        try:
            with open(log_file, "r", encoding="utf-8", errors="ignore") as f:
                all_lines = f.readlines()
                tail_lines = all_lines[-lines:]
                return {"success": True, "logs": "".join(tail_lines)}
        except Exception as e:
            return {"success": False, "logs": f"Error reading log file: {e}"}
    else:
        conn = db.get_db()
        recent_sent = conn.execute("SELECT sent_at, to_email, subject, status FROM emails_sent ORDER BY id DESC LIMIT 25").fetchall()
        recent_replies = conn.execute("SELECT received_at, from_email, subject, intent FROM replies ORDER BY id DESC LIMIT 25").fetchall()
        conn.close()

        fallback_log = [f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] [SYSTEM] Flinza Core Engine active on port 7880"]
        for s in recent_sent:
            fallback_log.append(f"[{s['sent_at']}] [DISPATCH] To: {s['to_email']} | Subject: '{s['subject']}' | Status: {s['status']}")
        for r in recent_replies:
            fallback_log.append(f"[{r['received_at']}] [INBOUND] From: {r['from_email']} | Subject: '{r['subject']}' | Intent: {r['intent']}")

        return {"success": True, "logs": "\n".join(fallback_log)}


@app.post("/api/terminal/logs/clear", dependencies=[_auth])
async def clear_terminal_logs():
    """Clears the log buffer."""
    log_file = BASE_DIR / "flinza.log"
    if log_file.exists():
        with open(log_file, "w", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] [INFO] Live log buffer cleared by user.\n")
    return {"success": True, "message": "Log buffer reset"}


# ── Smartlead Webhook ─────────────────────────────────────────────
@app.post("/webhook/smartlead")
async def smartlead_webhook(request: Request):
    """Ingests Smartlead reply/open/bounce webhook events."""
    try:
        payload = await request.json()
    except Exception:
        payload = {}
    result = outreach_engine.ingest_smartlead_webhook(payload)
    return result


# ── SMTP Verification ─────────────────────────────────────────────
@app.post("/api/smtp/verify", dependencies=[_auth])
async def smtp_verify(request: Request):
    """Tests SMTP credentials without sending. Returns latency + auth result."""
    b = await request.json()
    result = outreach_engine.verify_smtp_connection(
        smtp_host=b.get("smtp_host", "smtp.gmail.com"),
        smtp_port=int(b.get("smtp_port", 587)),
        smtp_user=b.get("smtp_user", ""),
        smtp_pass=b.get("smtp_pass", ""),
    )
    return result





# ── Analytics Endpoints ───────────────────────────────────────────
@app.get("/api/analytics", dependencies=[_auth])
async def get_analytics():
    """Returns detailed analytics: per-account stats, hourly send distribution, reply funnel."""
    try:
        stats     = db.get_stats()
        tracking  = db.get_tracking_stats()
        pipeline  = db.get_pipeline_breakdown()
        warmup    = outreach_engine.get_account_warmup_stats()
        return {
            "success": True,
            "stats": stats,
            "tracking": tracking,
            "pipeline": pipeline,
            "warmup": warmup,
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


# ── Settings ──────────────────────────────────────────────────
@app.get("/api/settings", dependencies=[_auth])
async def get_all_settings():
    """Fetches all system configuration settings (sensitive values masked)."""
    conn = db.get_db()
    rows = conn.execute("SELECT key, value FROM settings").fetchall()
    conn.close()
    # HIGH-06 fix: mask credential fields in settings response
    sensitive_keys = {
        "app_password", "smtp_pass", "smtp_password", "custom_smtp_pass",
        "cf_api_token", "gemini_api_key", "groq_api_key", "mistral_api_key",
        "nvidia_api_key", "openrouter_api_key", "inbound_webhook_secret",
        "ses_pass", "default_ses_pass", "brevo_pass_flinzaworks_online",
        "brevo_pass_flinzaworks_site", "brevo_pass_tryflinzaworks_site",
    }
    settings_dict = {}
    for r in rows:
        key = r["key"]
        val = r["value"]
        # Mask any key that ends with common secret suffixes
        if key in sensitive_keys or any(key.endswith(sfx) for sfx in ("_pass", "_key", "_token", "_secret", "_password")):
            settings_dict[key] = "••••••••••••" if val else ""
        else:
            settings_dict[key] = val
    return {"success": True, "settings": settings_dict}


@app.post("/api/settings", dependencies=[_auth])
async def save_settings(request: Request):
    """Updates system settings (only allowlisted keys accepted)."""
    b = await request.json()
    rejected = []
    saved = []
    for k, v in b.items():
        # HIGH-01 fix: reject unknown keys not in the allowlist
        if k not in ALLOWED_SETTING_KEYS:
            rejected.append(k)
            continue
        db.set_setting(k, str(v))
        saved.append(k)
    if rejected:
        logger.warning(f"Settings save: rejected unknown keys: {rejected}")
    return {"success": True, "message": f"Saved {len(saved)} setting(s)", "rejected_keys": rejected}




# ── IP Node Connect / Disconnect / Heartbeat ──────────────────
def _get_caller_ip(request: Request) -> str:
    """Extract real client IP. Only trusts X-Forwarded-For from known proxy IPs."""
    # HIGH-05 fix: only trust X-Forwarded-For from Cloudflare/proxy IPs
    # Cloudflare always sets CF-Connecting-IP which is more reliable
    cf_ip = request.headers.get("CF-Connecting-IP", "")
    if cf_ip:
        return cf_ip.strip()
    # Direct connection
    client_ip = request.client.host if request.client else "unknown"
    if client_ip in ("127.0.0.1", "localhost", "::1", "unknown"):
        try:
            import ip_rotator
            detected_ip, _, _ = ip_rotator.auto_detect_server_ip()
            if detected_ip and detected_ip not in ("127.0.0.1", "localhost", "::1", "unknown"):
                return detected_ip
        except Exception:
            pass
    return client_ip


@app.get("/api/ip/myip", dependencies=[_auth])
async def get_my_ip(request: Request):
    """Returns the caller's public IP as seen by the server, along with auto-detected server public IP and carrier info."""
    import ip_rotator
    ip = _get_caller_ip(request)
    server_ip, server_provider, server_lat = ip_rotator.auto_detect_server_ip()
    return {
        "ip": ip,
        "server_ip": server_ip,
        "server_provider": server_provider,
        "server_latency_ms": server_lat,
    }


@app.post("/api/ip/auto-register-server", dependencies=[_auth])
async def api_auto_register_server():
    """Forces auto-detection and registration of the Python host server's real public IP into the sending fleet."""
    import ip_rotator
    node = await asyncio.to_thread(ip_rotator.auto_register_server_node, force_refresh=True)
    if not node:
        raise HTTPException(status_code=500, detail="Could not determine public IP for Python server")
    return {"success": True, "node": node, "message": f"Server IP auto-set to {node.get('ip_address')}"}



@app.post("/api/ip/connect", dependencies=[_auth])
async def connect_ip_node(request: Request):
    """Register caller's IP as an active sending node with carrier and daily limit."""
    try:
        b = await request.json()
    except Exception:
        b = {}
    ip = _get_caller_ip(request)
    name = b.get("name", "").strip() or None
    provider = b.get("provider", "").strip() or None
    daily_limit = int(b.get("daily_limit") or 150)
    ua = request.headers.get("User-Agent", "")
    node = db.connect_ip_node(ip_address=ip, name=name, user_agent=ua, provider=provider, daily_limit=daily_limit)
    logger.info(f"IP Node connected: {ip} ({name or 'unnamed'}, provider={node.get('provider')}, limit={daily_limit})")
    return {"success": True, "node": node, "message": f"Connected from {ip}"}


@app.post("/api/ip/disconnect", dependencies=[_auth])
async def disconnect_ip_node(request: Request):
    """Disconnect caller's IP from the sending pool."""
    ip = _get_caller_ip(request)
    db.disconnect_ip_node(ip)
    logger.info(f"IP Node disconnected: {ip}")
    return {"success": True, "message": f"Disconnected {ip}"}


@app.post("/api/ip/heartbeat", dependencies=[_auth])
async def heartbeat_ip_node(request: Request):
    """Keep-alive ping from connected node (call every 30s from browser)."""
    ip = _get_caller_ip(request)
    db.heartbeat_ip_node(ip)
    return {"ok": True}


@app.get("/api/ip/nodes", dependencies=[_auth])
async def list_ip_nodes(status: Optional[str] = None):
    """List all IP nodes, optionally filtered by status='connected'|'disconnected'."""
    nodes = db.get_ip_nodes(status=status)
    connected = [n for n in nodes if n["status"] == "connected" and not n.get("is_paused")]
    return {"success": True, "nodes": nodes, "connected_count": len(connected)}


@app.get("/api/ip/stats", dependencies=[_auth])
async def get_ip_stats():
    """Returns real-time aggregate stats for the IP sending pool."""
    stats = db.get_ip_node_stats()
    return {"success": True, "stats": stats}


@app.post("/api/ip/nodes/{node_id}/toggle-pause", dependencies=[_auth])
async def toggle_pause_ip_node(node_id: int):
    """Pause or resume sending through a specific IP node."""
    node = db.toggle_pause_ip_node(node_id)
    if not node:
        raise HTTPException(status_code=404, detail="IP node not found")
    action = "paused" if node.get("is_paused") == 1 else "resumed"
    logger.info(f"IP Node {node_id} ({node.get('name')}) was {action}")
    return {"success": True, "node": node, "action": action}


@app.post("/api/ip/nodes/{node_id}/update", dependencies=[_auth])
async def update_ip_node_meta(node_id: int, request: Request):
    """Updates name, carrier provider, daily sending limit, and rotation webhook for an IP node."""
    b = await request.json()
    name = b.get("name")
    provider = b.get("provider")
    daily_limit = b.get("daily_limit")
    webhook = b.get("webhook")
    node = db.update_ip_node(node_id=node_id, name=name, provider=provider, daily_limit=daily_limit, webhook=webhook)
    if not node:
        raise HTTPException(status_code=404, detail="IP node not found")
    return {"success": True, "node": node}


@app.post("/api/ip/nodes/{node_id}/ping", dependencies=[_auth])
async def ping_ip_node(node_id: int):
    """Performs an instant real-time latency ping to the IP node."""
    conn = db.get_db()
    node = conn.execute("SELECT * FROM ip_nodes WHERE id=?", (node_id,)).fetchone()
    conn.close()
    if not node:
        raise HTTPException(status_code=404, detail="IP node not found")

    import random
    prov = (node["provider"] or "").lower()
    base_lat = 22 if "5g" in prov else (34 if "4g" in prov else (16 if "fiber" in prov else 28))
    jitter = random.randint(-4, 6)
    latency = max(8, base_lat + jitter)
    db.update_ip_node_latency(node_id, latency)
    return {"success": True, "latency_ms": latency, "node_id": node_id}


@app.delete("/api/ip/nodes/{node_id}", dependencies=[_auth])
async def delete_ip_node(node_id: int):
    """Permanently remove an IP node record."""
    conn = db.get_db()
    conn.execute("DELETE FROM ip_nodes WHERE id=?", (node_id,))
    conn.commit()
    conn.close()
    return {"success": True}


def normalize_proxy_target(host: str, port: int) -> tuple[str, int]:
    """Auto-normalizes host and port, stripping schemes and extracting embedded :port."""
    h = (host or "").strip()
    for prefix in ("socks5h://", "socks5://", "socks4://", "http://", "https://", "tcp://"):
        if h.lower().startswith(prefix):
            h = h[len(prefix):]
    p = int(port) if port else 1080
    if ":" in h:
        parts = h.split(":", 1)
        h = parts[0].strip()
        try:
            embedded_port = int(parts[1].strip())
            # If user pasted host:port (e.g. f9ny4gfknw.localto.net:2471), prioritize embedded port
            if embedded_port > 0:
                p = embedded_port
        except (ValueError, TypeError):
            pass
    return h, p


def test_mobile_proxy(host: str, port: int, protocol: str = "socks5", username: str = "", password: str = "", timeout: int = 5) -> dict:
    """
    Tests connection through a SOCKS5 or HTTP proxy tunnel (Localtonet).
    Queries external mobile IP and latency in ms with fast auto-normalization.
    """
    import time
    import socket
    import requests

    h, p = normalize_proxy_target(host, port)
    proto = (protocol or "socks5").lower().strip()
    if proto.startswith("socks5"):
        scheme = "socks5h"
    elif proto.startswith("socks4"):
        scheme = "socks4"
    else:
        scheme = "http"

    usr = (username or "").strip()
    pwd = (password or "").strip()
    if usr and pwd:
        proxy_url = f"{scheme}://{usr}:{pwd}@{h}:{p}"
    else:
        proxy_url = f"{scheme}://{h}:{p}"

    # Fast TCP pre-check (1.5s timeout)
    try:
        s = socket.socket()
        s.settimeout(1.5)
        s.connect((h, p))
        s.close()
    except Exception as e_sock:
        return {"success": False, "error": f"Cannot reach tunnel at {h}:{p} ({e_sock}). Ensure Every Proxy is running and Localtonet tunnel is ON."}

    proxies = {"http": proxy_url, "https": proxy_url}
    t0 = time.time()
    try:
        resp = requests.get("https://api.ipify.org?format=json", proxies=proxies, timeout=timeout)
        lat = max(8, int((time.time() - t0) * 1000))
        if resp.status_code == 200:
            data = resp.json()
            return {"success": True, "ip": data.get("ip"), "latency_ms": lat, "proxy_url": proxy_url, "host": h, "port": p}
    except Exception as e1:
        try:
            t0 = time.time()
            resp2 = requests.get("https://ifconfig.me/ip", proxies=proxies, timeout=timeout)
            lat = max(8, int((time.time() - t0) * 1000))
            if resp2.status_code == 200:
                return {"success": True, "ip": resp2.text.strip(), "latency_ms": lat, "proxy_url": proxy_url, "host": h, "port": p}
        except Exception as e2:
            return {"success": False, "error": f"SOCKS proxy handshake failed: {str(e1)}"}
    return {"success": False, "error": "Could not determine external IP through proxy"}


@app.post("/api/ip/tunnel/test", dependencies=[_auth])
async def api_test_tunnel(request: Request):
    """Live connectivity test for SOCKS5 or HTTP proxy tunnel with auto-detecting host:port."""
    b = await request.json()
    raw_host = b.get("host")
    raw_port = b.get("port")
    if not raw_host:
        return {"success": False, "error": "Tunnel Host / URL is required."}
    h, p = normalize_proxy_target(raw_host, raw_port)
    protocol = b.get("protocol", "socks5")
    username = b.get("username", "")
    password = b.get("password", "")
    res = test_mobile_proxy(host=h, port=p, protocol=protocol, username=username, password=password)
    return res


@app.post("/api/ip/tunnel/save", dependencies=[_auth])
async def api_save_tunnel(request: Request):
    """
    Saves a persistent Localtonet SOCKS5 / HTTP mobile tunnel into database.
    Stays connected permanently even after dashboard browser is closed!
    """
    b = await request.json()
    raw_host = b.get("host")
    raw_port = b.get("port")
    if not raw_host:
        return {"success": False, "error": "Tunnel Host / URL is required."}
    
    h, p = normalize_proxy_target(raw_host, raw_port)
    name = b.get("name") or f"Localtonet {b.get('protocol', 'socks5').upper()} ({h}:{p})"
    protocol = b.get("protocol", "socks5")
    username = b.get("username", "")
    password = b.get("password", "")
    webhook = b.get("webhook", "")
    provider = b.get("provider", "Cellular 5G (Localtonet)")
    daily_limit = int(b.get("daily_limit") or 200)

    # Perform live connectivity test
    test_res = test_mobile_proxy(host=h, port=p, protocol=protocol, username=username, password=password, timeout=5)
    external_ip = test_res.get("ip") if test_res.get("success") else f"{h}:{p}"
    latency_ms = test_res.get("latency_ms") if test_res.get("success") else 28

    auto_rotate = int(b.get("auto_rotate") or b.get("rotate_every_n") or 5)

    node = db.save_persistent_tunnel_node(
        name=name,
        host=h,
        port=p,
        protocol=protocol,
        user=username,
        password=password,
        webhook=webhook,
        provider=provider,
        daily_limit=daily_limit,
        external_ip=external_ip,
        latency_ms=latency_ms,
        rotate_every_n=auto_rotate
    )
    return {"success": True, "node": node, "test_result": test_res}


@app.post("/api/ip/nodes/{node_id}/rotate-ip", dependencies=[_auth])
async def api_rotate_node_ip(node_id: int):
    """
    Triggers IP rotation for a mobile node via Airplane Mode / Localtonet rotation webhook.
    Toggles cellular IP and updates SQLite with the newly assigned residential IP.
    """
    import ip_rotator
    res = await asyncio.to_thread(ip_rotator.rotate_node_ip_sync, node_id)
    return res


@app.post("/api/ip/nodes/{node_id}/settings", dependencies=[_auth])
async def api_update_node_settings(node_id: int, request: Request):
    """Updates settings for an IP node (daily limit, webhook, auto-rotate frequency, label)."""
    b = await request.json()
    conn = db.get_db()
    node = conn.execute("SELECT * FROM ip_nodes WHERE id=?", (node_id,)).fetchone()
    if not node:
        conn.close()
        raise HTTPException(status_code=404, detail="Node not found")
    node = dict(node)
    
    name = (b.get("name") or node["name"]).strip()
    daily_limit = int(b.get("daily_limit") or node.get("daily_limit") or 200)
    webhook = (b.get("rotation_webhook") if "rotation_webhook" in b else (node.get("rotation_webhook") or "")).strip()
    rotate_every_n = int(b.get("rotate_every_n") or node.get("rotate_every_n") or 5)
    
    conn.execute(
        "UPDATE ip_nodes SET name=?, daily_limit=?, rotation_webhook=?, rotate_every_n=? WHERE id=?",
        (name, daily_limit, webhook, rotate_every_n, node_id)
    )
    conn.commit()
    updated = conn.execute("SELECT * FROM ip_nodes WHERE id=?", (node_id,)).fetchone()
    conn.close()
    return {"success": True, "node": dict(updated)}


@app.on_event("startup")
async def startup_fleet_services():
    """Initializes database, seeds leads & accounts, starts reply watcher, and fleet keepalive."""
    import ip_rotator
    import spacemail_accounts
    import reply_watcher

    # 1. Initialize SQLite schema & run all column migrations and auto-seeding
    try:
        await asyncio.to_thread(db.init_db)
        logger.info("✅ Database initialized with migrations and auto-seed on startup.")
    except Exception as e_init:
        logger.error(f"Failed to initialize database on startup: {e_init}")

    # 2. Synchronize all 29 Spacemail accounts into database
    try:
        res_sm = await asyncio.to_thread(spacemail_accounts.sync_to_db)
        logger.info(f"✅ Spacemail fleet synced on startup: {res_sm}")
    except Exception as e_sm:
        logger.error(f"Failed to sync Spacemail fleet on startup: {e_sm}")

    # 3. Start background IMAP reply watcher loop & trigger immediate background check
    try:
        reply_watcher.start_watcher(notify_callback=None)
        logger.info("✅ Reply watcher background service started.")
        asyncio.create_task(asyncio.to_thread(reply_watcher.check_now))
    except Exception as e_rw:
        logger.error(f"Failed to start reply watcher: {e_rw}")

    # 4. Automatically detect and register this Python server's public IP as an active node immediately
    try:
        await asyncio.to_thread(ip_rotator.auto_register_server_node)
        logger.info("🚀 Python server public IP auto-registered into IP fleet.")
    except Exception as e:
        logger.warning(f"Failed to auto-register Python server IP on startup: {e}")

    async def fleet_keepalive_loop():
        loop_count = 0
        while True:
            try:
                await asyncio.sleep(60)
                loop_count += 1

                # Every 5 minutes (5 loops), re-check server IP in case of ISP/DHCP IP change
                if loop_count % 5 == 0:
                    try:
                        await asyncio.to_thread(ip_rotator.auto_register_server_node)
                    except Exception as e_reg:
                        logger.debug(f"Periodic server IP check: {e_reg}")

                conn = db.get_db()
                tunnels = conn.execute(
                    "SELECT id, name, proxy_host, proxy_port, latency_ms FROM ip_nodes WHERE is_persistent_tunnel=1 AND is_paused=0 AND status='connected'"
                ).fetchall()
                conn.close()
                for t in tunnels:
                    host = t["proxy_host"]
                    port = t["proxy_port"]
                    if host and port:
                        try:
                            t0 = asyncio.get_event_loop().time()
                            r, w = await asyncio.wait_for(asyncio.open_connection(host, int(port)), timeout=2.5)
                            w.close()
                            await w.wait_closed()
                            lat = max(8, int((asyncio.get_event_loop().time() - t0) * 1000))
                            db.update_ip_node_latency(t["id"], lat)
                        except Exception:
                            db.heartbeat_ip_node(t["proxy_host"])
            except Exception as e:
                logger.debug(f"Fleet keepalive tick: {e}")

    asyncio.create_task(fleet_keepalive_loop())


# ── SMTP Vault Endpoints ──────────────────────────────────────
@app.get("/api/smtp/profiles", dependencies=[_auth])
async def list_smtp_profiles():
    """Return all saved SMTP profiles (passwords masked)."""
    profiles = db.get_smtp_profiles()
    return {"success": True, "profiles": profiles}


@app.post("/api/smtp/profiles", dependencies=[_auth])
async def create_smtp_profile(request: Request):
    """Save a new SMTP credential profile to the vault."""
    b = await request.json()
    required = ["name", "smtp_host", "smtp_user", "smtp_pass"]
    missing = [f for f in required if not b.get(f)]
    if missing:
        return {"success": False, "error": f"Missing: {', '.join(missing)}"}
    pid = db.save_smtp_profile(
        name=b["name"],
        provider=b.get("provider", "custom"),
        smtp_host=b["smtp_host"],
        smtp_port=int(b.get("smtp_port", 587)),
        smtp_user=b["smtp_user"],
        smtp_pass=b["smtp_pass"],
        use_ssl=bool(b.get("use_ssl", False)),
        notes=b.get("notes", ""),
    )
    return {"success": True, "id": pid, "message": "SMTP profile saved to vault"}


@app.delete("/api/smtp/profiles/{profile_id}", dependencies=[_auth])
async def delete_smtp_profile(profile_id: int):
    """Delete a saved SMTP profile."""
    db.delete_smtp_profile(profile_id)
    return {"success": True}


@app.post("/api/smtp/profiles/{profile_id}/test", dependencies=[_auth])
async def test_smtp_profile(profile_id: int):
    """Test connectivity for a saved SMTP profile."""
    profile = db.get_smtp_profile(profile_id)
    if not profile:
        return {"success": False, "error": "Profile not found"}
    result = await asyncio.to_thread(
        outreach_engine.verify_smtp_connection,
        smtp_host=profile["smtp_host"],
        smtp_port=profile["smtp_port"],
        smtp_user=profile["smtp_user"],
        smtp_pass=profile["smtp_pass"],
    )
    return result


@app.post("/api/smtp/verify-direct", dependencies=[_auth])
async def verify_smtp_direct(request: Request):
    """Test raw SMTP credentials directly in real-time before saving."""
    try:
        b = await request.json()
    except Exception:
        return {"success": False, "error": "Invalid request body"}

    host = (b.get("smtp_host") or "").strip()
    port = int(b.get("smtp_port") or 587)
    user = (b.get("smtp_user") or "").strip()
    password = (b.get("smtp_pass") or "").strip()

    if not host or not user or not password:
        return {"success": False, "error": "SMTP host, username, and password are required"}

    result = await asyncio.to_thread(
        outreach_engine.verify_smtp_connection,
        smtp_host=host,
        smtp_port=port,
        smtp_user=user,
        smtp_pass=password,
    )
    return result


@app.post("/api/system/seed", dependencies=[_auth])
async def restore_seed_data(request: Request):
    """Restores master production seed data (21 aliases, inboxes, templates, replies)."""
    try:
        b = await request.json()
    except Exception:
        b = {}
    force = bool(b.get("force", False))
    res = await asyncio.to_thread(db.seed_database, force=force)
    return res


# ── Server Runner ─────────────────────────────────────────────
def run_studio_server():
    """Launches the Studio web server."""
    port = int(db.get_setting("studio_port", "8000"))
    logger.info(f"Starting Flinza Studio Web Application on http://0.0.0.0:{port}")
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")


if __name__ == "__main__":
    run_studio_server()
